# NativeDev — Project Architecture Summary (AI Agent Handoff)

## 1. Project Identity

**Project:** NativeDev

**Type:**

GTK4 + Python Linux desktop application

**Purpose:**

NativeDev is a **native Linux PHP development environment control plane**.

It is not a container system.

Philosophy:

> Use native Linux packages and services, then provide a modern GUI management layer around them.

Primary use case:

* PHP web development workstation
* Native Nginx + PHP-FPM
* Multiple PHP versions
* Local domains
* Development databases
* Developer tools
* Service lifecycle management

Current target:

```text
Debian / Ubuntu family Linux desktop
```

Future direction:

```text
Linux-first architecture

Current:
Debian / Ubuntu

Future:
Fedora
Arch
other systemd Linux distributions
```

---

# 2. Core Architecture

High-level flow:

```
GTK GUI
   |
Controller
   |
Managers
   |
System abstraction
   |
Polkit privileged helper
   |
Linux services/filesystem/package manager
```

Important principle:

> GUI never executes arbitrary root commands.

The GUI requests semantic operations.

Example:

Allowed:

```
php.ini.apply
database.postgresql.ensure_cluster
application.update
```

Not allowed:

```
sudo execute this command
run this SQL
write this arbitrary file
```

---

# 3. Privileged Helper Architecture

Files:

```
src/nativedev/system.py
src/nativedev/privileged_helper.py
```

Current protocol:

```
23
```

Flow:

```
GUI
 |
system.py
 |
pkexec
 |
privileged_helper.py
```

Rules:

* Fixed actions only
* No arbitrary shell execution
* No arbitrary filesystem paths
* No arbitrary SQL from client
* Root credentials are never permanently stored

---

# 4. Installation Architecture

NativeDev distribution:

```
.deb package
```

Current package:

```
nativedev_0.2.0_all.deb
```

Reason:

NativeDev itself is Python/GTK.

Therefore:

```
Architecture: all
```

Third-party binaries can still be architecture-specific.

Example:

```
Mailpit

x86_64 → amd64 binary
ARM → arm64 binary
```

---

# 5. Release / Update Architecture

Current update model:

```
GitHub Releases
```

Repository:

```
github.com/sayedsahin/nativedev
```

No APT repository currently.

## Update check

Frequency:

```
Every 24 hours
```

Background:

```
Application starts
       |
check timestamp
       |
>=24h?
       |
GitHub latest release API
       |
compare version
       |
show update dialog
```

No automatic installation.

---

## Update flow

```
GitHub Release
        |
        |
nativedev_X.Y.Z_all.deb
        |
        |
download
        |
        |
verify SHA256 digest
        |
        |
Polkit action
        |
        |
install package
        |
        |
restart NativeDev
```

Important:

GitHub is only update source.

Root helper does not trust GUI-provided URL.

Helper knows:

```
sayedsahin/nativedev
```

---

# 6. Package Lifecycle

## Upgrade

Upgrade must not remove user environment.

Example:

```
0.2.0 → 0.2.1
```

should preserve:

```
projects
databases
services
developer tools
configuration
```

---

## Uninstall Philosophy

NativeDev is a **service management application**.

Therefore:

> NativeDev removal does not mean removing everything configured through NativeDev.

Only NativeDev core responsibility is removed.

---

# 7. Uninstall Contract

## Remove

Only Local Development infrastructure:

```
Wildcard TLD DNS
```

Example:

```
*.test
```

and:

```
Park directory wildcard Nginx router
```

Example:

```
myproject.test
```

Remove:

```
/etc/nginx/.../nativedev-localdev.conf
NetworkManager dnsmasq configuration
```

---

## Preserve

Everything else:

```
Nginx
MariaDB
PostgreSQL
Redis
RabbitMQ

Mailpit

Adminer
Adminer SQLite

phpMyAdmin

NativeDev PHP INI

PHP-FPM configuration

database data

database users

projects

park directory
```

Reason:

NativeDev is only the management layer.

---

# 8. Filesystem Ownership Model

Important:

Do not mix application files and runtime-generated files.

Correct:

```
/usr/lib/nativedev/
```

Contains:

```
package-owned application code only
```

Example:

```
python modules
GUI code
manager code
```

---

System configuration:

```
/etc/nativedev/
```

Example:

```
application configuration
```

---

Runtime/generated data:

```
/var/lib/nativedev/
```

Example:

```
adminer-sqlite wrapper
generated state
```

---

User configuration:

```
~/.config/nativedev/
```

Example:

```
PHP profiles
LocalDev settings
preferences
```

---

# 9. Local Development Architecture

NativeDev's unique feature:

```
*.test / custom TLD development
```

Architecture:

```
Browser

example.test

      |
      |

Wildcard DNS

      |
      |

Nginx wildcard router

      |
      |

Park directory

      |
      |

project folder
```

Example:

```
~/Projects/myapp

myapp.test

        |
        |
public/ exists?
        |
        +--> public/

otherwise

        +--> project root
```

---

## LocalDev ownership

NativeDev owns:

```
DNS
+
park wildcard routing
```

NativeDev does not own:

```
Adminer localhost routes
phpMyAdmin localhost routes
Mailpit routes
```

---

# 10. Developer Tools Architecture

Separate from LocalDev.

Example:

```
adminer.localhost
phpmyadmin.localhost
adminer-sqlite.localhost
```

are Developer Tool integrations.

Nginx:

```
/etc/nginx/conf.d/

nativedev-tools.conf
```

contains:

```
Adminer
phpMyAdmin
other developer tools
```

They survive NativeDev uninstall.

---

# 11. Services Architecture

Services page:

```
Services & tools
```

Sections:

```
SYSTEM SERVICES

Nginx
MariaDB / MySQL
PostgreSQL
Redis
Memcached
RabbitMQ


SYSTEM TOOLS

Composer
mkcert


DEVELOPER TOOLS

phpMyAdmin
Adminer
Adminer SQLite
Mailpit
```

---

# 12. Database Philosophy

NativeDev creates development identities.

Current user:

Example:

Linux:

```
sayed
```

Database:

```
sayed
```

Default password:

```
nativedev
```

Linux password and database password are independent.

---

## MariaDB

UI:

```
Server:
localhost:3306

Username:
current Linux user
```

NativeDev does:

```
create/reset development account
```

Never stores:

```
MariaDB root password
```

---

## PostgreSQL

UI:

```
Server:
localhost:5432

Database:
postgres

Username:
current Linux user
```

Role:

```
LOGIN
CREATEDB
NOSUPERUSER
NOCREATEROLE
NOREPLICATION
```

Never make developer role superuser by default.

---

# 13. Database Uninstall

Default:

Preserve:

```
database data
database users
roles
passwords
```

No:

```
autoremove
database wipe
user deletion
```

Destructive operations require explicit confirmation.

---

# 14. PHP Architecture

Provider migration:

```
System PHP
      |
      |
      v
Multi PHP
```

One-way.

No normal UI rollback.

---

## Providers

Debian:

```
packages.sury.org/php
```

Ubuntu:

```
ppa:ondrej/php
```

Future:

Backend based.

---

# 15. PHP Extensions

Manager:

```
PhpExtensionManager
```

Responsibilities:

```
CLI + FPM
```

always together.

States:

```
Install

Disable / Uninstall

Enable / Uninstall

Built-in

Unavailable
```

---

# 16. PHP INI Architecture

Manager:

```
PhpIniManager
```

Never edit distro php.ini directly.

NativeDev layer:

```
/etc/php/X.Y/mods-available/nativedev.ini
```

linked:

```
CLI
FPM
```

---

Blocked directives:

```
extension
zend_extension
extension_dir
auto_prepend_file
auto_append_file
```

Reason:

Security and responsibility separation.

Extensions are managed by:

```
PhpExtensionManager
```

---

# 17. Node Architecture

Migration:

```
System Node

      |

      v

NVM Multi Node
```

One-way.

Once NVM enabled:

```
System Node provider hidden
```

---

# 18. Mailpit Architecture

Mailpit is a developer tool.

Installed from:

```
third-party source
```

Managed by NativeDev.

But uninstall:

```
preserve Mailpit
```

because NativeDev is only management layer.

---

# 19. Adminer / phpMyAdmin Architecture

They are Developer Tools.

Not LocalDev.

URLs:

```
adminer.localhost

phpmyadmin.localhost
```

They are independent from:

```
.test domain
```

---

# 20. Adminer SQLite

Special wrapper:

Purpose:

passwordless SQLite development login.

Architecture:

```
Adminer

+

Adminer plugin

+

SQLite wrapper
```

Location:

```
/var/lib/nativedev/adminer-sqlite/
```

Not:

```
/usr/lib/nativedev
```

because it is runtime-generated state.

---

# 21. Distro Abstraction

Never spread:

```
if Debian
if Ubuntu
```

everywhere.

Use backend model:

```
LinuxDistribution

        |

PackageBackend

        |

ServiceBackend
```

Future:

```
APT
DNF
Pacman
```

---

# 22. Manager Classes

Important managers:

```
DatabaseAccessManager

Doctor

LocalDevManager

NodeManager

PhpManager

PhpIniManager

PhpExtensionManager
```

When adding manager:

Always update:

```
src/nativedev/managers/__init__.py
```

and add import regression test.

---

# 23. Testing

Primary:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

Compile:

```bash
python -m compileall -q src tests
```

Shell:

```bash
bash -n script
```

Current known:

```
165/165 tests passed
```

(Only valid for tested tree.)

---

# 24. GUI Architecture Rules

Sidebar:

```
Dashboard

Local development

Services & tools

PHP

Node.js

Projects

Doctor
```

PHP children:

```
PHP

 ├─ Extensions
 └─ Settings
```

Not sidebar items.

---

# 25. Navigation Rules

Important:

PHP:

```
Extensions
Settings
```

Back:

```
PHP page
```

No automatic refresh.

Refresh only when state transition requires it.

---

# 26. CSS/UI Rules

Preserve:

```css
button {
  min-height:15px;
}
```

Status pills:

Must not stretch when subtitle/version exists.

Use:

```
GTK_ALIGN_CENTER
```

---

# 27. Error Handling Philosophy

Never report success from intermediate command only.

Example:

Bad:

```
SQL command exit 0
=
success
```

Correct:

```
SQL command
+
fresh login verification
=
success
```

Same applies to:

```
PHP-FPM validation
Database credentials
Service startup
```

---

# 28. Future AI Agent Rules

Before coding:

1. Inspect current source.
2. Do not rebuild from old archive.
3. Preserve privileged boundary.
4. Preserve current Linux user identity model.
5. Preserve Linux-first backend architecture.
6. Do not remove user data.
7. Do not introduce arbitrary root execution.
8. Update only required files.
9. Run tests.
10. Check manager exports.
11. If protocol changes:

    * update client
    * update helper
    * tell user to reinstall package.

---

# Final Project Vision

NativeDev is:

```
A Linux-native PHP development workstation manager
```

not:

```
Docker replacement
server panel
hosting control panel
sudo wrapper
```

Its responsibility:

```
Make local PHP development easy

while respecting native Linux services.
```

The key architectural boundary:

```
NativeDev owns:

Local development routing
(TLD + Park directory)


NativeDev manages:

System services and developer tools


NativeDev does NOT own:

User data
Databases
Projects
The entire Linux machine
```