from __future__ import annotations

from dataclasses import dataclass

from .config import AppConfig
from .provider_uninstall import ProviderAwareNativeDevController, ProviderNodeManager
from .managers import ApplicationManager, DatabaseAccessManager, DeveloperToolManager, Doctor, LocalDevManager, PhpExtensionManager, PhpIniManager, PhpManager
from .services import ServiceManager
from .system import AptManager, CommandRunner, DistroInfo, SystemdManager, read_os_release


@dataclass(slots=True)
class AppContext:
    distro: DistroInfo
    config: AppConfig
    runner: CommandRunner
    apt: AptManager
    systemd: SystemdManager
    php: PhpManager
    php_extensions: PhpExtensionManager
    php_ini: PhpIniManager
    node: ProviderNodeManager
    database_access: DatabaseAccessManager
    application: ApplicationManager
    developer_tools: DeveloperToolManager
    services: ServiceManager
    localdev: LocalDevManager
    doctor: Doctor
    controller: ProviderAwareNativeDevController

    @classmethod
    def create(cls) -> "AppContext":
        distro = read_os_release()
        config = AppConfig.load()
        runner = CommandRunner()
        apt = AptManager(runner)
        systemd = SystemdManager(runner)
        php = PhpManager(runner, apt, systemd, distro)
        php_extensions = PhpExtensionManager(runner, apt, systemd, php)
        php_ini = PhpIniManager(runner, systemd, php)
        node = ProviderNodeManager(runner, apt)
        database_access = DatabaseAccessManager(runner)
        application = ApplicationManager(runner, distro)
        developer_tools = DeveloperToolManager(runner, apt, php, config, systemd)
        services = ServiceManager(runner, apt, systemd)
        localdev = LocalDevManager(runner, apt, systemd, config, php)
        doctor = Doctor(distro, apt, systemd, php, node, developer_tools, services, localdev)
        controller = ProviderAwareNativeDevController(
            php,
            localdev,
            node,
            php_ini,
            services,
            database_access,
            developer_tools,
            application,
        )
        return cls(
            distro,
            config,
            runner,
            apt,
            systemd,
            php,
            php_extensions,
            php_ini,
            node,
            database_access,
            application,
            developer_tools,
            services,
            localdev,
            doctor,
            controller,
        )
