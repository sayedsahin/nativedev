from __future__ import annotations

import html
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import __version__
from .context import AppContext
from .services import COMPONENTS, ComponentSpec
from .managers.database_access import DatabaseAdminPasswordRequired, DatabaseAccessManager, DEFAULT_DATABASE_PASSWORD
from .managers.application import ApplicationUpdate
from .managers.developer_tools import DEVELOPER_WEB_TOOLS
from gi.repository import Gtk


class Worker:
    def __init__(self):
        # Read-only probes may run concurrently. Every mutating action goes
        # through one queue so multi-command transactions cannot interleave.
        self.read_pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="nativedev-read")
        self.mutation_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="nativedev-mutate")

    def _submit_to(self, pool: ThreadPoolExecutor, fn: Callable, success: Callable | None = None, error: Callable | None = None):
        future = pool.submit(fn)

        def done(f):
            try:
                value = f.result()
            except Exception as exc:  # noqa: BLE001 - UI boundary
                if error:
                    GLib.idle_add(error, exc)
            else:
                if success:
                    GLib.idle_add(success, value)

        future.add_done_callback(done)

    def submit(self, fn: Callable, success: Callable | None = None, error: Callable | None = None):
        self._submit_to(self.read_pool, fn, success, error)

    def submit_mutation(self, fn: Callable, success: Callable | None = None, error: Callable | None = None):
        self._submit_to(self.mutation_pool, fn, success, error)

    def shutdown(self):
        self.read_pool.shutdown(wait=False, cancel_futures=True)
        self.mutation_pool.shutdown(wait=False, cancel_futures=True)


def label(text: str = "", css: str | None = None, *, wrap: bool = False) -> Gtk.Label:
    widget = Gtk.Label(label=text, xalign=0)
    widget.set_wrap(wrap)
    if wrap:
        # WORD_CHAR also breaks long paths/commands with no convenient spaces,
        # preventing diagnostic text from increasing the window's minimum width.
        widget.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    widget.set_selectable(css == "error-text")
    if css == "error-text":
        widget.set_max_width_chars(90)
    if css:
        widget.add_css_class(css)
    return widget


def _constrain_dialog_text(widget: Gtk.Label, max_width_chars: int = 52) -> Gtk.Label:
    """Keep explanatory/validation text compact inside modal dialogs."""
    widget.set_max_width_chars(max_width_chars)
    widget.set_wrap(True)
    widget.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    return widget


def page_header(
    title: str,
    subtitle: str,
    refresh: Callable | None = None,
    *,
    back: Callable | None = None,
) -> Gtk.Widget:
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    outer.set_margin_bottom(18)

    if back:
        back_button = Gtk.Button(label="← PHP")
        back_button.set_halign(Gtk.Align.START)
        back_button.connect("clicked", lambda *_: back())
        outer.append(back_button)

    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
    copy.set_hexpand(True)
    copy.append(label(title, "page-title"))
    copy.append(label(subtitle, "muted", wrap=True))
    row.append(copy)
    if refresh:
        button = Gtk.Button(label="Refresh")
        button.set_valign(Gtk.Align.CENTER)
        button.connect("clicked", lambda *_: refresh())
        row.append(button)
    outer.append(row)
    return outer


def card() -> Gtk.Box:
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    box.add_css_class("card")
    return box


def status_pill(text: str, ok: bool | None = None) -> Gtk.Label:
    widget = label(text, "pill")
    # Gtk.Box gives children FILL vertical alignment by default.  A status
    # pill beside a multi-line title/subtitle would therefore stretch to the
    # full row height and make its CSS padding look much larger.  Keep pills
    # at their natural height regardless of sibling content.
    widget.set_valign(Gtk.Align.CENTER)
    if ok is True:
        widget.add_css_class("status-ok")
    elif ok is False:
        widget.add_css_class("status-warn")
    return widget


def confirm(parent: Gtk.Window, title: str, message: str, on_accept: Callable[[], None]):
    dialog = Gtk.MessageDialog(
        transient_for=parent,
        modal=True,
        message_type=Gtk.MessageType.QUESTION,
        buttons=Gtk.ButtonsType.CANCEL,
        text=title,
        secondary_text=message,
    )
    dialog.add_button("Continue", Gtk.ResponseType.OK)

    def response(_dialog, response_id):
        dialog.destroy()
        if response_id == Gtk.ResponseType.OK:
            on_accept()

    dialog.connect("response", response)
    dialog.present()


def confirm_database_uninstall(
    parent: Gtk.Window,
    title: str,
    on_accept: Callable[[bool], None],
) -> None:
    dialog = Gtk.Dialog(title=title, transient_for=parent, modal=True)
    dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
    uninstall = dialog.add_button("Uninstall", Gtk.ResponseType.OK)
    uninstall.add_css_class("destructive-action")

    content = dialog.get_content_area()
    content.set_spacing(10)
    content.set_margin_top(12)
    content.set_margin_bottom(12)
    content.set_margin_start(12)
    content.set_margin_end(12)
    content.append(label(
        "Packages and NativeDev configuration will be removed.\n"
        "Existing database data and accounts will be preserved.",
        wrap=True,
    ))
    delete_data = Gtk.CheckButton(label="Delete all database data and accounts")
    delete_data.set_active(False)
    content.append(delete_data)

    def response(_dialog, response_id):
        selected = bool(delete_data.get_active())
        dialog.destroy()
        if response_id == Gtk.ResponseType.OK:
            on_accept(selected)

    dialog.connect("response", response)
    dialog.present()


def prompt_database_password(
    parent: Gtk.Window,
    title: str,
    on_accept: Callable[[str], None],
) -> None:
    dialog = Gtk.Dialog(title=title, transient_for=parent, modal=True)
    dialog.set_default_size(440, -1)
    dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
    dialog.add_button("Change", Gtk.ResponseType.OK)
    content = dialog.get_content_area()
    content.set_spacing(8)
    content.set_margin_top(12)
    content.set_margin_bottom(12)
    content.set_margin_start(12)
    content.set_margin_end(12)

    note = _constrain_dialog_text(label(
        "Use 1-128 characters: letters, numbers, or !@#$%^&*()_+-=.,:?/",
        "muted",
        wrap=True,
    ))
    password_label = label("New password", "row-title")
    password = Gtk.PasswordEntry()
    password.set_hexpand(True)
    password.set_show_peek_icon(True)
    confirm_password_label = label("Confirm password", "row-title")
    confirm_password = Gtk.PasswordEntry()
    confirm_password.set_hexpand(True)
    confirm_password.set_show_peek_icon(True)
    error = _constrain_dialog_text(label("", "error-text", wrap=True))
    error.set_visible(False)
    content.append(note)
    content.append(password_label)
    content.append(password)
    content.append(confirm_password_label)
    content.append(confirm_password)
    content.append(error)

    def response(_dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            dialog.destroy()
            return
        value = password.get_text()
        if value != confirm_password.get_text():
            error.set_text("Passwords do not match")
            error.set_visible(True)
            return
        try:
            DatabaseAccessManager.validate_password(value)
        except Exception as exc:  # UI validation mirrors the manager/helper contract.
            error.set_text(str(exc))
            error.set_visible(True)
            return
        dialog.destroy()
        on_accept(value)

    dialog.connect("response", response)
    dialog.present()


def prompt_existing_database_password(
    parent: Gtk.Window,
    title: str,
    username: str,
    on_accept: Callable[[str], None],
) -> None:
    dialog = Gtk.Dialog(title=title, transient_for=parent, modal=True)
    dialog.set_default_size(440, -1)
    dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
    dialog.add_button("Use user", Gtk.ResponseType.OK)
    content = dialog.get_content_area()
    content.set_spacing(8)
    content.set_margin_top(12)
    content.set_margin_bottom(12)
    content.set_margin_start(12)
    content.set_margin_end(12)

    content.append(_constrain_dialog_text(label(
        f'Enter the current database password for "{username}". NativeDev will verify it and save the credential without changing the account password. A wrong password changes nothing.',
        "muted",
        wrap=True,
    )))
    password_label = label("Current database password", "row-title")
    password = Gtk.PasswordEntry()
    password.set_hexpand(True)
    password.set_show_peek_icon(True)
    error = _constrain_dialog_text(label("", "error-text", wrap=True))
    error.set_visible(False)
    content.append(password_label)
    content.append(password)
    content.append(error)

    def response(_dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            dialog.destroy()
            return
        value = password.get_text()
        try:
            DatabaseAccessManager.validate_password(value)
        except Exception as exc:
            error.set_text(str(exc))
            error.set_visible(True)
            return
        dialog.destroy()
        on_accept(value)

    dialog.connect("response", response)
    dialog.present()


def prompt_database_admin_password(
    parent: Gtk.Window,
    title: str,
    on_accept: Callable[[str], None],
) -> None:
    dialog = Gtk.Dialog(title=title, transient_for=parent, modal=True)
    dialog.set_default_size(440, -1)
    dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
    dialog.add_button("Continue", Gtk.ResponseType.OK)
    content = dialog.get_content_area()
    content.set_spacing(8)
    content.set_margin_top(12)
    content.set_margin_bottom(12)
    content.set_margin_start(12)
    content.set_margin_end(12)

    content.append(_constrain_dialog_text(label(
        "NativeDev could not authenticate the local MariaDB/MySQL root account without a password. "
        "Enter the database root password for this one operation. It will not be saved.",
        "muted",
        wrap=True,
    )))
    content.append(label("MariaDB/MySQL root password", "row-title"))
    password = Gtk.PasswordEntry()
    password.set_hexpand(True)
    password.set_show_peek_icon(True)
    error = _constrain_dialog_text(label("", "error-text", wrap=True))
    error.set_visible(False)
    content.append(password)
    content.append(error)

    def response(_dialog, response_id):
        if response_id != Gtk.ResponseType.OK:
            dialog.destroy()
            return
        value = password.get_text()
        try:
            DatabaseAccessManager.validate_admin_password(value)
        except Exception as exc:
            error.set_text(str(exc))
            error.set_visible(True)
            return
        dialog.destroy()
        on_accept(value)

    dialog.connect("response", response)
    dialog.present()


class Page(Gtk.ScrolledWindow):
    def __init__(self, window: "MainWindow"):
        super().__init__()
        self.window = window
        self.context = window.context
        self.worker = window.worker
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        self.body.set_margin_top(28)
        self.body.set_margin_bottom(28)
        self.body.set_margin_start(28)
        self.body.set_margin_end(28)
        self.set_child(self.body)

    def busy(self, widget: Gtk.Widget, active: bool):
        widget.set_sensitive(not active)

    def action(self, button: Gtk.Button, fn: Callable, *, success_message: str, after: Callable | None = None):
        self.busy(button, True)
        self.window.set_activity(True, "Working…")

        def success(_value=None):
            self.busy(button, False)
            self.window.set_activity(False, success_message)
            if after:
                after()
            return False

        def error(exc):
            self.busy(button, False)
            self.window.set_activity(False, str(exc), error=True)
            # Mutations can legitimately fail after a partial system change
            # (for example, APT installation succeeded but post-install database
            # provisioning failed). Refresh the page on error too so the UI
            # reflects the real system state instead of leaving a stale Install
            # button until the user refreshes manually.
            if after:
                after()
            return False

        self.worker.submit_mutation(
            lambda: self.context.controller.run_mutation(fn), success, error
        )


class DashboardPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("Dashboard", "Native system development services at a glance.", self.refresh))
        self.system_card = card()
        self.environment_card = card()
        self.body.append(self.system_card)
        self.body.append(self.environment_card)
        self.refresh()

    def refresh(self):
        self._replace(self.system_card, [label("Loading system status…", "muted")])
        self._replace(self.environment_card, [label("Checking development environment…", "muted")])

        def collect():
            php = self.context.php.installed_versions()
            return {
                "distro": self.context.distro.pretty_name,
                "supported": self.context.distro.is_debian_family,
                "php": php,
                "node": self.context.node.current_node(),
                "node_provider": self.context.node.provider(),
                "projects": len(self.context.localdev.projects()),
                "dns": self.context.localdev.dns_ready(),
                "nginx": self.context.systemd.is_active("nginx"),
            }

        def done(data):
            system = [label("System", "section-title")]
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            row.append(label(data["distro"]))
            row.append(status_pill("Supported" if data["supported"] else "Unsupported", data["supported"]))
            system.append(row)
            self._replace(self.system_card, system)

            env = [label("Environment", "section-title")]
            env.extend([
                self._metric("PHP", ", ".join(data["php"]) if data["php"] else "Not installed", bool(data["php"])),
                self._metric("Node", (f"{data['node']} · {data['node_provider'].upper()}" if data["node"] else "Not installed"), bool(data["node"])),
                self._metric("Nginx", "Running" if data["nginx"] else "Stopped / missing", data["nginx"]),
                self._metric(f"*.{self.context.config.domain}", "Ready" if data["dns"] else "Not configured", data["dns"]),
                self._metric("Projects", str(data["projects"]), None),
            ])
            self._replace(self.environment_card, env)
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    @staticmethod
    def _metric(name: str, value: str, ok: bool | None) -> Gtk.Widget:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        row.append(label(name, "row-title"))
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        row.append(spacer)
        row.append(status_pill(value, ok))
        return row

    @staticmethod
    def _replace(container: Gtk.Box, children: list[Gtk.Widget]):
        while child := container.get_first_child():
            container.remove(child)
        for child in children:
            container.append(child)


class PhpPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("PHP", "One active PHP provider: System PHP or distro-appropriate Multi-PHP.", self.refresh))
        tools = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        tools.append(label("Manage", "section-title"))
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        tools.append(spacer)
        extensions = Gtk.Button(label="Extensions")
        extensions.connect("clicked", lambda *_: self.window.open_php_subpage("extensions"))
        tools.append(extensions)
        settings = Gtk.Button(label="Settings")
        settings.connect("clicked", lambda *_: self.window.open_php_subpage("php_ini"))
        tools.append(settings)
        self.body.append(tools)
        self.repo_card = card()
        self.versions_card = card()
        self.body.append(self.repo_card)
        self.body.append(self.versions_card)
        self.refresh()

    def refresh(self):
        self._clear(self.repo_card, "Checking repository…")
        self._clear(self.versions_card, "Loading PHP versions…")

        def collect():
            provider = self.context.php.provider()
            installed = self.context.php.installed_versions()
            available = self.context.php.available_versions() if provider == "multi" else []
            installed_sorted = sorted(installed, key=self.context.php._version_key, reverse=True)
            available_sorted = sorted(
                set(available).difference(installed),
                key=self.context.php._version_key,
                reverse=True,
            )
            versions = installed_sorted + available_sorted
            fpm = {}
            for version in versions:
                fpm_installed = self.context.apt.is_installed(f"php{version}-fpm")
                config_ready = self.context.php.fpm_config_ready(version) if fpm_installed else False
                fpm[version] = {
                    "installed": fpm_installed,
                    "config_ready": config_ready,
                    "running": self.context.php.fpm_running(version) if config_ready else False,
                    "enabled_state": self.context.php.fpm_enabled_state(version) if fpm_installed else "n/a",
                    "developer_pool": self.context.php.developer_pool_configured(version) if config_ready else False,
                }
            return {
                "provider": provider,
                "multi_backend": self.context.php.multi_php_backend(),
                "multi_name": self.context.php.multi_php_repository_name,
                "multi_migration_needed": self.context.php.multi_php_migration_needed() if provider == "multi" else False,
                "multi_supported": self.context.php.multi_php_supported,
                "codename": self.context.distro.codename,
                "installed": installed,
                "available": available,
                "versions": versions,
                "cli": self.context.php.cli_version(),
                "developer_user": self.context.php.developer_user,
                "fpm": fpm,
            }

        def done(data):
            self._build_repo(data)
            self._build_versions(data)
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    def _build_repo(self, data):
        self._remove_all(self.repo_card)
        self.repo_card.append(label("PHP provider", "section-title"))
        provider = data["provider"]
        provider_name = "System" if provider == "system" else (data["multi_name"] if provider == "multi" else "Not configured")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.append(status_pill(provider_name, provider in {"system", "multi"}))
        if data["cli"]:
            row.append(label(f"Default PHP {data['cli']}", "muted"))
        row.set_hexpand(True)
        self.repo_card.append(row)

        if provider == "system":
            self.repo_card.append(label(
                "NativeDev is using the distribution's system PHP. Existing PHP can serve *.test through NativeDev's per-user FPM pool.",
                "muted", wrap=True,
            ))
            button = Gtk.Button(label="Enable Multi-PHP")
            button.set_sensitive(data["multi_supported"] and self.context.distro.is_debian_family)
            button.add_css_class("suggested-action")
            installed_text = ", ".join(f"PHP {v}" for v in data["installed"]) or "the current System PHP runtime"
            button.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Enable Multi-PHP?",
                    f"NativeDev will configure {data['multi_name']}, migrate {installed_text} from the system PHP provider in place, keep the current default where possible, and reconcile *.test. Once Multi-PHP is active NativeDev will no longer offer System PHP as another provider.",
                    lambda: self.action(button, self.context.controller.enable_multi_php, success_message="Multi-PHP enabled", after=self.refresh),
                ),
            )
            self.repo_card.append(button)
        elif provider == "multi":
            self.repo_card.append(label(
                f"{data['multi_name']} multi-version PHP is active. NativeDev manages PHP versions through this repository while it remains configured.",
                "muted", wrap=True,
            ))
            if data["multi_migration_needed"]:
                self.repo_card.append(label(
                    "Some installed PHP packages still appear to come from the previous system provider. Complete the one-way migration to normalize them to Multi-PHP.",
                    "error-text", wrap=True,
                ))
                migrate = Gtk.Button(label="Complete Multi-PHP migration")
                migrate.add_css_class("suggested-action")
                migrate.connect(
                    "clicked",
                    lambda *_: confirm(
                        self.window,
                        "Complete Multi-PHP migration?",
                        f"NativeDev will reinstall the currently installed PHP runtimes from {data['multi_name']} candidates, preserve the current default where possible, and reconcile *.test. System PHP will not be offered as a second provider.",
                        lambda: self.action(migrate, self.context.controller.enable_multi_php, success_message="Multi-PHP migration completed", after=self.refresh),
                    ),
                )
                self.repo_card.append(migrate)
        else:
            self.repo_card.append(label("No PHP runtime is installed. You can install System PHP or enable Multi-PHP.", "muted", wrap=True))
            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            system = Gtk.Button(label="Install System PHP")
            system.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Install System PHP?",
                    "NativeDev will install the distribution's default PHP CLI/FPM and the standard local-development extension baseline, then configure its *.test FPM pool.",
                    lambda: self.action(system, self.context.controller.install_system_php, success_message="System PHP installed", after=self.refresh),
                ),
            )
            actions.append(system)
            multi = Gtk.Button(label="Enable Multi-PHP")
            multi.set_sensitive(data["multi_supported"] and self.context.distro.is_debian_family)
            multi.add_css_class("suggested-action")
            multi.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Enable Multi-PHP and install PHP?",
                    f"NativeDev will configure {data['multi_name']} and install its newest available PHP runtime with the standard local-development extension baseline. While Multi-PHP is active, System PHP will not be offered as another provider.",
                    lambda: self.action(multi, self.context.controller.enable_multi_php, success_message="Multi-PHP enabled", after=self.refresh),
                ),
            )
            actions.append(multi)
            self.repo_card.append(actions)

    def _build_versions(self, data):
        self._remove_all(self.versions_card)
        title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        title_row.append(label("PHP versions", "section-title"))
        if data["cli"]:
            title_row.append(status_pill(f"Default {data['cli']}", True))
        self.versions_card.append(title_row)
        if not data["versions"]:
            message = "No PHP versions are currently installed for the selected provider."
            self.versions_card.append(label(message, "muted"))
            return

        installed = set(data["installed"])
        available = set(data["available"])
        for version in data["versions"]:
            row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            row.add_css_class("service-row")
            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            name = label(f"PHP {version}", "row-title")
            name.set_hexpand(True)
            top.append(name)

            if version in installed:
                fpm = data["fpm"].get(version, {})
                if fpm.get("installed"):
                    if not fpm.get("config_ready"):
                        top.append(status_pill("FPM config missing", False))
                    else:
                        top.append(status_pill("FPM running" if fpm.get("running") else "FPM stopped", fpm.get("running")))
                        state = fpm.get("enabled_state", "unknown")
                        top.append(status_pill("Enabled" if state.startswith("enabled") else state.capitalize(), state.startswith("enabled") if state in {"enabled", "disabled"} else None))
                        if fpm.get("developer_pool"):
                            top.append(status_pill(f"*.test as {data['developer_user']}", True))
                        else:
                            top.append(status_pill("*.test pool not configured", None))
                else:
                    top.append(status_pill("CLI installed", True))
            else:
                top.append(status_pill("Available", None))
            row.append(top)

            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            if version in installed:
                default = Gtk.Button(label="Default")
                is_default = data["cli"] == version
                default.set_sensitive(not is_default)
                if not is_default:
                    default.add_css_class("suggested-action")
                    default.connect(
                        "clicked",
                        lambda _b, v=version, btn=default: confirm(
                            self.window,
                            f"Set PHP {v} as default?",
                            "NativeDev will use update-alternatives to change the default /usr/bin/php command.",
                            lambda: self.action(btn, lambda: self.context.controller.set_default_php(v), success_message=f"PHP {v} is now default", after=self.refresh),
                        ),
                    )
                actions.append(default)

                fpm = data["fpm"].get(version, {})
                if fpm.get("installed"):
                    if not fpm.get("config_ready"):
                        repair = Gtk.Button(label="Repair FPM")
                        repair.add_css_class("suggested-action")
                        repair.connect(
                            "clicked",
                            lambda _b, v=version, btn=repair: confirm(
                                self.window,
                                f"Repair PHP {v} FPM?",
                                f"The php{v}-fpm package is installed, but its master configuration is missing. NativeDev will reinstall that package with dpkg's missing-conffile restore mode. Existing custom configuration is not purged or overwritten.",
                                lambda: self.action(btn, lambda: self.context.controller.repair_php_fpm(v), success_message=f"PHP {v} FPM repaired", after=self.refresh),
                            ),
                        )
                        actions.append(repair)
                    else:
                        if not fpm.get("developer_pool"):
                            pool = Gtk.Button(label="Configure *.test pool")
                            pool.connect(
                                "clicked",
                                lambda _b, v=version, btn=pool: confirm(
                                    self.window,
                                    f"Configure PHP {v} for *.test?",
                                    f"NativeDev will create its own PHP-FPM pool running as {data['developer_user']}. The system/multi-PHP www pool is not modified.",
                                    lambda: self.action(btn, lambda: self.context.php.ensure_developer_pool(v), success_message=f"PHP {v} NativeDev pool configured", after=self.refresh),
                                ),
                            )
                            actions.append(pool)
                        if fpm.get("running"):
                            stop = Gtk.Button(label="Stop")
                            stop.connect("clicked", lambda _b, v=version, btn=stop: self.action(btn, lambda: self.context.php.stop_fpm(v), success_message=f"PHP {v} FPM stopped", after=self.refresh))
                            actions.append(stop)
                            restart = Gtk.Button(label="Restart")
                            restart.connect("clicked", lambda _b, v=version, btn=restart: self.action(btn, lambda: self.context.php.restart_fpm(v), success_message=f"PHP {v} FPM restarted", after=self.refresh))
                            actions.append(restart)
                        else:
                            start_btn = Gtk.Button(label="Start")
                            start_btn.connect("clicked", lambda _b, v=version, btn=start_btn: self.action(btn, lambda: self.context.php.start_fpm(v), success_message=f"PHP {v} FPM started", after=self.refresh))
                            actions.append(start_btn)

                        enabled_state = fpm.get("enabled_state")
                        if enabled_state == "enabled":
                            disable = Gtk.Button(label="Disable & Stop")
                            disable.connect("clicked", lambda _b, v=version, btn=disable: self.action(btn, lambda: self.context.php.disable_fpm(v), success_message=f"PHP {v} FPM disabled", after=self.refresh))
                            actions.append(disable)
                        elif enabled_state == "disabled":
                            enable = Gtk.Button(label="Enable")
                            enable.connect("clicked", lambda _b, v=version, btn=enable: self.action(btn, lambda: self.context.php.enable_fpm(v), success_message=f"PHP {v} FPM enabled", after=self.refresh))
                            actions.append(enable)

                uninstall = Gtk.Button(label="Uninstall")
                uninstall.add_css_class("destructive-action")
                uninstall.connect(
                    "clicked",
                    lambda _b, v=version, btn=uninstall: confirm(
                        self.window,
                        f"Uninstall PHP {v}?",
                        f"All installed php{v}-* packages managed by APT will be removed. Other PHP versions are not touched.",
                        lambda: self.action(btn, lambda: self.context.controller.uninstall_php(v), success_message=f"PHP {v} uninstalled", after=self.refresh),
                    ),
                )
                actions.append(uninstall)
            elif version in available:
                install = Gtk.Button(label="Install")
                install.add_css_class("suggested-action")
                install.connect(
                    "clicked",
                    lambda _b, v=version, btn=install: confirm(
                        self.window,
                        f"Install PHP {v}?",
                        "This installs CLI, FPM and common development extensions from your configured APT repositories.",
                        lambda: self.action(btn, lambda: self.context.controller.install_php(v), success_message=f"PHP {v} installed", after=self.refresh),
                    ),
                )
                actions.append(install)
            row.append(actions)
            self.versions_card.append(row)

    @staticmethod
    def _remove_all(box: Gtk.Box):
        while child := box.get_first_child():
            box.remove(child)

    def _clear(self, box: Gtk.Box, text: str):
        self._remove_all(box)
        box.append(label(text, "muted"))


class PhpExtensionsPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.selected_version: str | None = None
        self.body.append(
            page_header(
                "PHP Extensions",
                "Install, remove, enable or disable extensions for one PHP version. CLI and FPM are always changed together.",
                self.refresh,
                back=self.window.open_php_page,
            )
        )
        self.version_card = card()
        self.extensions_card = card()
        self.body.append(self.version_card)
        self.body.append(self.extensions_card)
        self.refresh()

    def refresh(self):
        # An explicit page Refresh follows the current system PHP default. This
        # matters when the default was changed on the PHP page while this page
        # instance remained alive in the Gtk.Stack.
        self._refresh(prefer_default=True)

    def refresh_selected(self):
        # Dropdown changes and extension mutations should keep the version the
        # user is actively working on instead of jumping back to the default.
        self._refresh(prefer_default=False)

    def _refresh(self, *, prefer_default: bool):
        self._replace(self.version_card, [label("Loading PHP versions…", "muted")])
        self._replace(self.extensions_card, [label("Loading extension state…", "muted")])

        def collect():
            versions = sorted(
                self.context.php_extensions.installed_versions(),
                key=self.context.php._version_key,
                reverse=True,
            )
            cli = self.context.php.cli_version()
            selected = ""
            if prefer_default and cli in versions:
                selected = cli
            elif self.selected_version in versions:
                selected = self.selected_version or ""
            elif cli in versions:
                selected = cli
            elif versions:
                selected = versions[0]
            states = self.context.php_extensions.states(selected) if selected else []
            runtime_modules = self.context.php_extensions.runtime_modules(selected) if selected else []
            return {
                "provider": self.context.php.provider(),
                "versions": versions,
                "selected": selected,
                "default": cli if cli in versions else "",
                "states": states,
                "runtime_modules": runtime_modules,
                "prerelease": self.context.php_extensions.is_prerelease(selected) if selected else False,
            }

        def done(data):
            self.selected_version = data["selected"] or None
            self._build_version_selector(data)
            self._build_extensions(data)
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    def _build_version_selector(self, data):
        children = [label("PHP version", "section-title")]
        versions = data["versions"]
        if not versions:
            children.append(label("Install a PHP runtime before managing extensions.", "muted", wrap=True))
            self._replace(self.version_card, children)
            return

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        default_version = data.get("default", "")
        version_labels = [
            f"PHP {version} · Default" if version == default_version else f"PHP {version}"
            for version in versions
        ]
        dropdown = Gtk.DropDown.new_from_strings(version_labels)
        selected_index = versions.index(data["selected"])
        dropdown.set_selected(selected_index)
        row.append(dropdown)
        provider_name = {"system": "System", "multi": "Multi-PHP"}.get(data["provider"], data["provider"].title())
        row.append(status_pill(provider_name, data["provider"] in {"system", "multi"}))
        if default_version:
            row.append(status_pill(f"Default PHP {default_version}", True))
        if data.get("prerelease"):
            prerelease = status_pill("Pre-release", False)
            prerelease.add_css_class("extension-status")
            row.append(prerelease)
        children.append(row)
        children.append(label(
            "Every action applies to CLI and FPM together. Refresh only reads state; it never re-enables an extension you disabled.",
            "muted", wrap=True,
        ))

        def changed(widget, _param):
            index = widget.get_selected()
            if index < 0 or index >= len(versions):
                return
            version = versions[index]
            if version == self.selected_version:
                return
            self.selected_version = version
            self.refresh_selected()

        dropdown.connect("notify::selected", changed)
        self._replace(self.version_card, children)

    def _build_extensions(self, data):
        children: list[Gtk.Widget] = [label("Extensions", "section-title")]
        version = data["selected"]
        if not version:
            children.append(label("No PHP version selected.", "muted"))
            self._replace(self.extensions_card, children)
            return

        runtime_modules = data.get("runtime_modules", [])
        if runtime_modules:
            heading = label("Runtime / Core", "section-title")
            heading.set_margin_top(6)
            children.append(heading)
            for module in runtime_modules:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                row.add_css_class("service-row")
                name = label(module, "row-title")
                name.set_hexpand(True)
                row.append(name)
                status = status_pill("Built-in", True)
                status.add_css_class("extension-status")
                row.append(status)
                children.append(row)

        category = None
        for state in data["states"]:
            # Built-in catalog entries are rendered in Runtime / Core with the
            # selected runtime's real module inventory, never as fake packages.
            if state.built_in:
                continue

            spec = state.spec
            if spec.category != category:
                category = spec.category
                heading = label(category, "section-title")
                heading.set_margin_top(6)
                children.append(heading)

            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
            row.add_css_class("service-row")
            name = label(state.package, "row-title")
            name.set_hexpand(True)
            tooltip = spec.title
            if spec.note:
                tooltip += f" — {spec.note}"
            name.set_tooltip_text(tooltip)
            row.append(name)

            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

            if not state.installed and state.installable:
                install = Gtk.Button(label="Install")
                install.add_css_class("suggested-action")
                install.connect(
                    "clicked",
                    lambda _b, v=version, key=spec.key, title=spec.title, package=state.package, btn=install: confirm(
                        self.window,
                        f"Install {package}?",
                        f"NativeDev will install {package}, enable it for CLI and FPM together, validate PHP {v} FPM, then reload it when running.",
                        lambda: self.action(
                            btn,
                            lambda: self.context.php_extensions.install(v, key),
                            success_message=f"{package} installed and enabled",
                            after=self.refresh_selected,
                        ),
                    ),
                )
                actions.append(install)
            elif state.installed:
                if state.enabled:
                    disable = Gtk.Button(label="Disable")
                    disable.connect(
                        "clicked",
                        lambda _b, v=version, key=spec.key, package=state.package, btn=disable: self.action(
                            btn,
                            lambda: self.context.php_extensions.disable(v, key),
                            success_message=f"{package} disabled",
                            after=self.refresh_selected,
                        ),
                    )
                    actions.append(disable)
                else:
                    enable = Gtk.Button(label="Enable")
                    enable.add_css_class("suggested-action")
                    enable.connect(
                        "clicked",
                        lambda _b, v=version, key=spec.key, package=state.package, btn=enable: self.action(
                            btn,
                            lambda: self.context.php_extensions.enable(v, key),
                            success_message=f"{package} enabled",
                            after=self.refresh_selected,
                        ),
                    )
                    actions.append(enable)

                uninstall = Gtk.Button(label="Uninstall")
                uninstall.add_css_class("destructive-action")
                uninstall.connect(
                    "clicked",
                    lambda _b, v=version, key=spec.key, package=state.package, btn=uninstall: confirm(
                        self.window,
                        f"Uninstall {package}?",
                        f"NativeDev will APT-remove {package} after a dependency safety preflight. It does not purge PHP configuration. CLI and FPM lose the extension together.",
                        lambda: self.action(
                            btn,
                            lambda: self.context.php_extensions.uninstall(v, key),
                            success_message=f"{package} uninstalled",
                            after=self.refresh_selected,
                        ),
                    ),
                )
                actions.append(uninstall)

            if actions.get_first_child():
                row.append(actions)
            elif not state.installable:
                status = status_pill("Unavailable", False)
                status.add_css_class("extension-status")
                row.append(status)

            children.append(row)

        self._replace(self.extensions_card, children)

    @staticmethod
    def _replace(container: Gtk.Box, children: list[Gtk.Widget]):
        while child := container.get_first_child():
            container.remove(child)
        for child in children:
            container.append(child)



class PhpIniPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.selected_version: str | None = None
        self.pending_settings: dict[str, str] = {}
        self.applied_settings: dict[str, str] = {}
        self.effective_settings: dict[str, str] = {}
        self.saved_profile: dict[str, str] = {}
        self.body.append(
            page_header(
                "PHP Settings",
                "Per-version NativeDev INI overrides. System/multi-PHP php.ini files are never edited; CLI and FPM use the same override layer.",
                self.refresh,
                back=self.window.open_php_page,
            )
        )
        self.version_card = card()
        self.settings_card = card()
        self.body.append(self.version_card)
        self.body.append(self.settings_card)
        self.refresh()

    def refresh(self):
        self._refresh(prefer_default=True)

    def refresh_selected(self):
        self._refresh(prefer_default=False)

    def _refresh(self, *, prefer_default: bool):
        self._replace(self.version_card, [label("Loading PHP versions…", "muted")])
        self._replace(self.settings_card, [label("Loading PHP settings…", "muted")])

        def collect():
            versions = sorted(
                self.context.php_ini.installed_versions(),
                key=self.context.php._version_key,
                reverse=True,
            )
            cli = self.context.php.cli_version()
            selected = ""
            if prefer_default and cli in versions:
                selected = cli
            elif self.selected_version in versions:
                selected = self.selected_version or ""
            elif cli in versions:
                selected = cli
            elif versions:
                selected = versions[0]

            settings = self.context.php_ini.settings(selected) if selected else {}
            effective = self.context.php_ini.effective_settings(selected, tuple(settings)) if settings else {}
            profile = self.context.php_ini.saved_profile(selected) if selected else {}
            return {
                "provider": self.context.php.provider(),
                "versions": versions,
                "selected": selected,
                "default": cli if cli in versions else "",
                "settings": settings,
                "effective": effective,
                "profile": profile,
            }

        def done(data):
            self.selected_version = data["selected"] or None
            self.pending_settings = dict(data["settings"])
            self.applied_settings = dict(data["settings"])
            self.effective_settings = dict(data["effective"])
            self.saved_profile = dict(data["profile"])
            self._build_version_selector(data)
            self._render_settings_card()
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    def _build_version_selector(self, data):
        children = [label("PHP version", "section-title")]
        versions = data["versions"]
        if not versions:
            children.append(label("Install a PHP runtime before managing PHP settings.", "muted", wrap=True))
            self._replace(self.version_card, children)
            return

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        default_version = data.get("default", "")
        version_labels = [
            f"PHP {version} · Default" if version == default_version else f"PHP {version}"
            for version in versions
        ]
        dropdown = Gtk.DropDown.new_from_strings(version_labels)
        dropdown.set_selected(versions.index(data["selected"]))
        row.append(dropdown)
        provider_name = {"system": "System", "multi": "Multi-PHP"}.get(data["provider"], data["provider"].title())
        row.append(status_pill(provider_name, data["provider"] in {"system", "multi"}))
        if default_version:
            row.append(status_pill(f"Default PHP {default_version}", True))
        children.append(row)
        children.append(
            label(
                "NativeDev writes only 99-nativedev.ini for CLI and FPM. Extension loading is managed on PHP Extensions; extension/zend_extension directives are rejected here.",
                "muted",
                wrap=True,
            )
        )

        def changed(widget, _param):
            index = widget.get_selected()
            if index < 0 or index >= len(versions):
                return
            version = versions[index]
            if version == self.selected_version:
                return
            self.selected_version = version
            self.refresh_selected()

        dropdown.connect("notify::selected", changed)
        self._replace(self.version_card, children)

    def _render_settings_card(self):
        version = self.selected_version
        children: list[Gtk.Widget] = [label("NativeDev overrides", "section-title")]
        if not version:
            children.append(label("No PHP version selected.", "muted"))
            self._replace(self.settings_card, children)
            return

        if self.saved_profile and not self.applied_settings:
            restore_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            restore_note = label(
                f"Saved NativeDev settings were found for PHP {version}, but they are not currently active.",
                "muted",
                wrap=True,
            )
            restore_note.set_hexpand(True)
            restore_box.append(restore_note)
            restore = Gtk.Button(label="Restore saved settings")
            restore.add_css_class("suggested-action")
            restore.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    f"Restore PHP {version} settings?",
                    "NativeDev will restore the saved per-version override profile for CLI and FPM, validate both runtimes, and reload FPM only if it is already running.",
                    lambda: self.action(
                        restore,
                        lambda: self.context.php_ini.restore_profile(version),
                        success_message=f"PHP {version} settings restored",
                        after=self.refresh_selected,
                    ),
                ),
            )
            restore_box.append(restore)
            children.append(restore_box)

        has_unsaved_changes = self.pending_settings != self.applied_settings

        if self.pending_settings:
            for directive in sorted(self.pending_settings, key=str.casefold):
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                row.add_css_class("service-row")
                name = label(directive, "row-title")
                name.set_size_request(220, -1)
                row.append(name)

                value = Gtk.Entry()
                value.set_text(self.pending_settings[directive])
                value.set_hexpand(True)
                value.connect(
                    "changed",
                    lambda entry, key=directive: self.pending_settings.__setitem__(key, entry.get_text()),
                )
                row.append(value)

                if directive in self.effective_settings:
                    effective = label(f"Current effective: {self.effective_settings[directive]}", "muted")
                    effective.set_tooltip_text("Effective value reported by the selected PHP CLI before any unsaved edits")
                    row.append(effective)

                remove = Gtk.Button(label="Remove")
                remove.connect("clicked", lambda _b, key=directive: self._remove_pending(key))
                row.append(remove)
                children.append(row)

        elif has_unsaved_changes:
            children.append(label("All NativeDev overrides are marked for removal. Save to apply this change.", "muted"))
        else:
            children.append(label("No NativeDev overrides are active for this PHP version.", "muted"))

        # Keep Save/Reset visible while there are rows *or* an unsaved removal.
        # In particular, removing the final persisted override leaves an empty
        # pending mapping that still needs to be saved (apply({}) performs reset).
        if self.pending_settings or has_unsaved_changes:
            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            save = Gtk.Button(label="Save")
            save.add_css_class("suggested-action")
            save.connect(
                "clicked",
                lambda *_: self.action(
                    save,
                    lambda: self.context.php_ini.apply(version, dict(self.pending_settings)),
                    success_message=f"PHP {version} settings saved",
                    after=self.refresh_selected,
                ),
            )
            actions.append(save)

            reset = Gtk.Button(label="Reset")
            reset.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    f"Reset PHP {version} NativeDev settings?",
                    "Only NativeDev's per-version override file and CLI/FPM links will be removed. System/multi-PHP php.ini files and PHP extension configuration are not changed.",
                    lambda: self.action(
                        reset,
                        lambda: self.context.php_ini.reset(version),
                        success_message=f"PHP {version} NativeDev settings reset",
                        after=self.refresh_selected,
                    ),
                ),
            )
            actions.append(reset)
            children.append(actions)

        add_heading = label("Add / update setting", "section-title")
        add_heading.set_margin_top(8)
        children.append(add_heading)

        add_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        suggestions = ("Suggested directive…", *self.context.php_ini.suggested_directives())
        suggestion = Gtk.DropDown.new_from_strings(list(suggestions))
        directive = Gtk.Entry()
        directive.set_placeholder_text("Directive, e.g. memory_limit")
        directive.set_hexpand(True)
        value = Gtk.Entry()
        value.set_placeholder_text("Value, e.g. 512M")
        value.set_hexpand(True)
        add = Gtk.Button(label="Add")
        add.add_css_class("suggested-action")

        def suggestion_changed(widget, _param):
            index = widget.get_selected()
            if index <= 0 or index >= len(suggestions):
                return
            directive.set_text(suggestions[index])

        def add_setting(*_):
            key = directive.get_text().strip()
            raw_value = value.get_text()
            try:
                self.context.php_ini.validate_setting(key, raw_value)
            except RuntimeError as exc:
                self.window.set_activity(False, str(exc), error=True)
                return
            self.pending_settings[key] = raw_value
            self._render_settings_card()

        suggestion.connect("notify::selected", suggestion_changed)
        add.connect("clicked", add_setting)
        value.connect("activate", add_setting)
        add_row.append(suggestion)
        add_row.append(directive)
        add_row.append(value)
        add_row.append(add)
        children.append(add_row)

        children.append(
            label(
                "Values are stored as one INI line. NativeDev rejects newline, carriage-return and NUL characters instead of silently stripping them.",
                "muted",
                wrap=True,
            )
        )

        self._replace(self.settings_card, children)

    def _remove_pending(self, directive: str):
        self.pending_settings.pop(directive, None)
        self._render_settings_card()

    @staticmethod
    def _replace(container: Gtk.Box, children: list[Gtk.Widget]):
        while child := container.get_first_child():
            container.remove(child)
        for child in children:
            container.append(child)


class NodePage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("Node.js", "One active Node provider: System Node or NVM multi-version Node.", self.refresh))
        self.nvm_card = card()
        self.node_card = card()
        self.body.append(self.nvm_card)
        self.body.append(self.node_card)
        self.refresh()

    def refresh(self):
        self._replace(self.nvm_card, [label("Checking Node provider…", "muted")])
        self._replace(self.node_card, [label("Loading Node.js state…", "muted")])

        def collect():
            provider = self.context.node.provider()
            nvm_installed = self.context.node.installed()
            releases = []
            lts_error = ""
            if provider == "nvm" and nvm_installed:
                try:
                    releases = self.context.node.available_lts()
                except Exception as exc:
                    lts_error = str(exc)
            removal_impact = []
            if self.context.node.system_node_installed():
                try:
                    removal_impact = self.context.node.system_removal_impact()
                except Exception as exc:
                    removal_impact = [f"Could not calculate APT impact: {exc}"]
            return {
                "provider": provider,
                "system_installed": self.context.node.system_node_installed(),
                "system_version": self.context.node.system_node_version(),
                "system_npm": self.context.node.system_npm_installed(),
                "removal_impact": removal_impact,
                "nvm_installed": nvm_installed,
                "nvm": self.context.node.nvm_version() if nvm_installed else "",
                "current": self.context.node.current_node(),
                "default": self.context.node.default_node() if nvm_installed else "",
                "versions": self.context.node.installed_versions() if nvm_installed else [],
                "lts": releases,
                "lts_error": lts_error,
                "rc": str(self.context.node.shell_rc()),
            }

        def done(data):
            self._build_provider(data)
            self._build_node_versions(data)
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    def _build_provider(self, data):
        provider = data["provider"]
        names = {"system": "System", "nvm": "NVM", "none": "Not configured"}
        children = [label("Node provider", "section-title")]
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.append(status_pill(names.get(provider, provider.title()), provider in {"system", "nvm"}))
        if provider == "system" and data["system_version"]:
            row.append(label(f"System {data['system_version']}", "muted"))
        elif data["nvm_installed"]:
            row.append(label(f"NVM {data['nvm'] or 'installed'} · Shell: {data['rc']}", "muted"))
        children.append(row)

        if provider == "system":
            children.append(label(
                "NativeDev is using the system Node.js packages. Multi-version Node is available by explicitly migrating to NVM.",
                "muted", wrap=True,
            ))
            if data["removal_impact"]:
                children.append(label(
                    "NVM migration is blocked because APT would also remove manually installed package(s): " + ", ".join(data["removal_impact"]),
                    "error-text", wrap=True,
                ))
            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            migrate = Gtk.Button(label="Enable NVM Multi-Node")
            migrate.add_css_class("suggested-action")
            migrate.set_sensitive(not data["removal_impact"])
            migrate.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Enable NVM multi-Node?",
                    f"NativeDev will remove System Node.js{('/npm' if data['system_npm'] else '')} and its automatically installed system Node dependency stack, then install/configure NVM, install an NVM-managed LTS runtime and set it as default. Manually installed packages are never removed implicitly.",
                    lambda: self.action(migrate, self.context.controller.enable_nvm_multi_node, success_message="NVM multi-Node enabled", after=self.refresh),
                ),
            )
            actions.append(migrate)
            remove = Gtk.Button(label="Uninstall System Node")
            remove.add_css_class("destructive-action")
            remove.set_sensitive(not data["removal_impact"])
            remove.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Uninstall System Node.js?",
                    "NativeDev will remove system nodejs/npm and their automatically installed Node dependency packages. Migration is blocked if APT would remove another manually installed package.",
                    lambda: self.action(remove, self.context.node.uninstall_system_node, success_message="System Node.js removed", after=self.refresh),
                ),
            )
            actions.append(remove)
            children.append(actions)

        elif provider == "nvm":
            children.append(label(
                "NVM multi-version Node is active. NativeDev manages Node versions through NVM and does not offer System Node as a second provider.",
                "muted", wrap=True,
            ))
            if data["system_installed"]:
                if data["removal_impact"]:
                    children.append(label(
                        "A System Node installation is still present, but cleanup is blocked because APT would also remove manually installed package(s): " + ", ".join(data["removal_impact"]),
                        "error-text", wrap=True,
                    ))
                else:
                    children.append(label(
                        "A System Node installation is still present from before NVM. Complete the migration to remove that runtime.",
                        "error-text", wrap=True,
                    ))
            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            shell_btn = Gtk.Button(label="Configure shell")
            shell_btn.connect("clicked", lambda *_: self.action(shell_btn, self.context.node.configure_shell, success_message="Shell integration configured"))
            actions.append(shell_btn)
            if data["system_installed"]:
                cleanup = Gtk.Button(label="Complete NVM migration")
                cleanup.add_css_class("suggested-action")
                cleanup.set_sensitive(not data["removal_impact"])
                cleanup.connect(
                    "clicked",
                    lambda *_: confirm(
                        self.window,
                        "Complete NVM migration?",
                        "NativeDev will remove the remaining system nodejs/npm packages, keep the NVM runtimes, ensure an NVM default, and retain NativeDev's NVM shell integration.",
                        lambda: self.action(cleanup, self.context.controller.enable_nvm_multi_node, success_message="NVM migration completed", after=self.refresh),
                    ),
                )
                actions.append(cleanup)
            children.append(actions)

        else:
            children.append(label("No Node.js runtime is installed. You can install System Node or enable NVM multi-version Node.", "muted", wrap=True))
            actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            debian = Gtk.Button(label="Install System Node")
            debian.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Install System Node.js?",
                    "NativeDev will install the distribution's nodejs package and npm when available.",
                    lambda: self.action(debian, self.context.node.install_system_node, success_message="System Node.js installed", after=self.refresh),
                ),
            )
            actions.append(debian)
            nvm = Gtk.Button(label="Enable NVM Multi-Node")
            nvm.add_css_class("suggested-action")
            nvm.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Enable NVM and install Node LTS?",
                    "NativeDev will install NVM for your user, install the latest LTS runtime and configure the NativeDev shell block. While NVM is active System Node will not be offered as another provider.",
                    lambda: self.action(nvm, self.context.controller.enable_nvm_multi_node, success_message="NVM multi-Node enabled", after=self.refresh),
                ),
            )
            actions.append(nvm)
            children.append(actions)

        self._replace(self.nvm_card, children)

    def _build_node_versions(self, data):
        provider = data["provider"]
        node = [label("Node.js versions", "section-title")]
        if provider == "system":
            if data["system_version"]:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                title = label(data["system_version"], "row-title")
                title.set_hexpand(True)
                row.append(title)
                row.append(status_pill("Installed · System · Default", True))
                node.append(row)
            else:
                node.append(label("System Node.js is not currently usable.", "muted"))
            self._replace(self.node_card, node)
            return

        if provider != "nvm":
            node.append(label("Choose a Node provider to manage versions.", "muted"))
            self._replace(self.node_card, node)
            return

        summary = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        summary.append(status_pill(f"Default: {data['default'] or 'none'}", bool(data["default"])))
        if data["current"]:
            summary.append(status_pill(f"Current: {data['current']}", True))
        node.append(summary)
        if data["lts_error"]:
            node.append(label(f"Could not refresh remote LTS list: {data['lts_error']}", "error-text", wrap=True))

        installed = set(data["versions"])
        release_names = {release.version: release.codename for release in data["lts"]}

        # Installed versions are deliberately rendered first; remote releases are
        # discovery/install choices and belong below the actual machine state.
        for version in data["versions"]:
            node.append(self._node_version_row(version, release_names.get(version, "Installed"), installed, data["default"]))

        available = [release for release in data["lts"] if release.version not in installed]
        if available:
            node.append(label("Available LTS releases", "section-title"))
            for release in available:
                node.append(self._node_version_row(release.version, release.codename, installed, data["default"]))
        elif not data["versions"]:
            node.append(label("No NVM-managed Node.js versions found.", "muted"))

        self._replace(self.node_card, node)

    def _node_version_row(self, version: str, subtitle: str, installed: set[str], default_version: str) -> Gtk.Widget:
        row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        row.add_css_class("service-row")
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        copy.set_hexpand(True)
        copy.append(label(version, "row-title"))
        copy.append(label(subtitle, "muted"))
        top.append(copy)
        is_installed = version in installed
        if is_installed and default_version == version:
            top.append(status_pill("Installed · Default", True))
        else:
            top.append(status_pill("Installed" if is_installed else "Available", True if is_installed else None))
        row.append(top)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        if is_installed:
            default = Gtk.Button(label="Default")
            is_default = default_version == version
            default.set_sensitive(not is_default)
            if not is_default:
                default.add_css_class("suggested-action")
                default.connect(
                    "clicked",
                    lambda _b, v=version, btn=default: self.action(
                        btn, lambda: self.context.node.set_default(v), success_message=f"Node {v} is now default", after=self.refresh
                    ),
                )
            actions.append(default)

            uninstall = Gtk.Button(label="Uninstall")
            uninstall.add_css_class("destructive-action")
            uninstall.connect(
                "clicked",
                lambda _b, v=version, btn=uninstall: confirm(
                    self.window,
                    f"Uninstall Node {v}?",
                    "This removes only this NVM-managed Node.js version from your user account.",
                    lambda: self.action(btn, lambda: self.context.node.uninstall_version(v), success_message=f"Node {v} uninstalled", after=self.refresh),
                ),
            )
            actions.append(uninstall)
        else:
            install = Gtk.Button(label="Install")
            install.add_css_class("suggested-action")
            install.connect(
                "clicked",
                lambda _b, v=version, btn=install: self.action(
                    btn, lambda: self.context.node.install_version(v), success_message=f"Node {v} installed", after=self.refresh
                ),
            )
            actions.append(install)
        row.append(actions)
        return row

    @staticmethod
    def _replace(container: Gtk.Box, children: list[Gtk.Widget]):
        while child := container.get_first_child():
            container.remove(child)
        for child in children:
            container.append(child)


class ServicesPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("Services & tools", "Install, remove and control system components.", self.refresh))
        note = label("System authentication is requested once per NativeDev session; privileged actions reuse the restricted helper until the app closes.", "muted", wrap=True)
        self.body.append(note)
        self.list_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.body.append(self.list_box)
        self.refresh()

    def refresh(self):
        self._clear()
        self.list_box.append(label("Detecting installed components…", "muted"))

        def collect():
            components = {}
            for spec in COMPONENTS:
                state = self.context.services.state(spec)
                database = None
                if state.installed and self.context.database_access.supports(spec.key):
                    try:
                        database = self.context.database_access.state(spec.key)
                    except Exception as exc:
                        database = exc
                components[spec.key] = (state, database)
            developer_tools = [self.context.developer_tools.state(spec) for spec in DEVELOPER_WEB_TOOLS]
            adminer_sqlite = self.context.developer_tools.adminer_sqlite_state()
            return components, developer_tools, adminer_sqlite

        def done(data):
            components, developer_tools, adminer_sqlite = data
            self._clear()

            system_services = self._section_panel(
                "SYSTEM SERVICES",
                "Native background services managed through systemd.",
            )
            self.list_box.append(system_services)
            for key in ("nginx", "mariadb", "postgresql", "redis", "memcached", "rabbitmq"):
                state, database = components[key]
                system_services.append(self._service_component_card(state, database))

            system_tools = self._section_panel(
                "SYSTEM TOOLS",
                "System-wide command-line tools installed from trusted package sources.",
            )
            self.list_box.append(system_tools)
            for key in ("composer", "mkcert"):
                state, database = components[key]
                system_tools.append(self._service_component_card(state, database))

            developer_tools_box = self._section_panel(
                "DEVELOPER TOOLS",
                "Local utilities for database administration, mail testing and development workflows.",
            )
            self.list_box.append(developer_tools_box)
            nginx_installed = components["nginx"][0].installed
            for state in developer_tools:
                developer_tools_box.append(self._developer_web_tool_card(state, nginx_installed))
                if state.spec.key == "adminer":
                    developer_tools_box.append(self._adminer_sqlite_card(adminer_sqlite, nginx_installed))
            mailpit_state, mailpit_database = components["mailpit"]
            developer_tools_box.append(self._service_component_card(mailpit_state, mailpit_database))
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    @staticmethod
    def _section_panel(title: str, description: str) -> Gtk.Box:
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        section.add_css_class("services-section")

        header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        header.add_css_class("services-section-header")
        header.append(label(title, "services-section-title"))
        header.append(label(description, "services-section-description", wrap=True))
        section.append(header)

        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        separator.add_css_class("services-section-separator")
        section.append(separator)
        return section

    def _service_component_card(self, state, database):
        spec = state.spec
        box = card()
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        copy.set_hexpand(True)
        copy.append(label(spec.title, "section-title"))
        if spec.key == "mariadb" and state.version:
            copy.append(label(f"Version {state.version}", "muted"))
        if spec.note:
            copy.append(label(spec.note, "muted", wrap=True))
        top.append(copy)
        if state.running:
            top.append(status_pill("Running", True))
        elif state.installed:
            top.append(status_pill("Installed", True))
        else:
            top.append(status_pill("Not installed", False))
        if spec.service and state.service_available:
            top.append(status_pill(state.enabled_state.capitalize(), state.enabled if state.enabled_state in {"enabled", "disabled"} else None))
        box.append(top)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        if not state.installed:
            install = Gtk.Button(label="Install")
            install.set_sensitive(state.installable and self.context.distro.is_debian_family)
            install.add_css_class("suggested-action")
            install.connect(
                "clicked",
                lambda _b, s=spec, btn=install: confirm(
                    self.window,
                    f"Install {s.title}?",
                    (
                        "NativeDev will install the official Mailpit Linux binary and a NativeDev-managed systemd service. "
                        "The Web UI and SMTP listener are bound to localhost only."
                        if s.key == "mailpit"
                        else "NativeDev will install the system package(s). Database services also receive the local development account automatically. Services are enabled and started when applicable."
                    ),
                    lambda: self.action(btn, lambda: self.context.controller.install_component(s), success_message=f"{s.title} installed", after=self.refresh),
                ),
            )
            actions.append(install)
        else:
            if spec.service and state.service_available:
                if state.running:
                    stop = Gtk.Button(label="Stop")
                    stop.connect("clicked", lambda _b, s=spec, btn=stop: self.action(btn, lambda: self.context.services.stop(s), success_message=f"{s.title} stopped", after=self.refresh))
                    actions.append(stop)
                    restart = Gtk.Button(label="Restart")
                    restart.connect("clicked", lambda _b, s=spec, btn=restart: self.action(btn, lambda: self.context.services.restart(s), success_message=f"{s.title} restarted", after=self.refresh))
                    actions.append(restart)
                else:
                    start_btn = Gtk.Button(label="Start")
                    start_btn.connect("clicked", lambda _b, s=spec, btn=start_btn: self.action(btn, lambda: self.context.services.start(s), success_message=f"{s.title} started", after=self.refresh))
                    actions.append(start_btn)

                if state.enabled_state == "enabled":
                    disable = Gtk.Button(label="Disable")
                    disable.connect("clicked", lambda _b, s=spec, btn=disable: self.action(btn, lambda: self.context.services.disable(s), success_message=f"{s.title} disabled", after=self.refresh))
                    actions.append(disable)
                elif state.enabled_state == "disabled":
                    enable = Gtk.Button(label="Enable")
                    enable.connect("clicked", lambda _b, s=spec, btn=enable: self.action(btn, lambda: self.context.services.enable(s), success_message=f"{s.title} enabled", after=self.refresh))
                    actions.append(enable)

            uninstall = Gtk.Button(label="Uninstall")
            uninstall.set_sensitive(state.uninstallable)
            uninstall.add_css_class("destructive-action")
            if state.uninstallable:
                if spec.key in {"mariadb", "postgresql"}:
                    uninstall.connect(
                        "clicked",
                        lambda _b, s=spec, btn=uninstall: confirm_database_uninstall(
                            self.window,
                            f"Uninstall {s.title}?",
                            lambda delete_data: self.action(
                                btn,
                                lambda: self.context.controller.uninstall_component(s, delete_database_data=delete_data),
                                success_message=(
                                    f"{s.title} uninstalled; database data and accounts deleted"
                                    if delete_data else f"{s.title} uninstalled"
                                ),
                                after=self.refresh,
                            ),
                        ),
                    )
                else:
                    uninstall.connect(
                        "clicked",
                        lambda _b, s=spec, btn=uninstall: confirm(
                            self.window,
                            f"Uninstall {s.title}?",
                            (
                                "NativeDev removes the managed Mailpit binary and systemd service. Stored Mailpit messages are preserved."
                                if s.key == "mailpit"
                                else "NativeDev removes this component's installed runtime package(s)."
                            ),
                            lambda: self.action(btn, lambda: self.context.controller.uninstall_component(s), success_message=f"{s.title} uninstalled", after=self.refresh),
                        ),
                    )
            actions.append(uninstall)
            if state.uninstall_note:
                box.append(label(state.uninstall_note, "muted", wrap=True))
        if actions.get_first_child():
            box.append(actions)

        if state.installed and self.context.database_access.supports(spec.key):
            self._append_database_access(box, spec, database)
        return box

    def _developer_web_tool_card(self, state, nginx_installed: bool):
        spec = state.spec
        box = card()
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        copy.set_hexpand(True)
        copy.append(label(spec.title, "section-title"))
        if state.version:
            copy.append(label(f"Version {state.version}", "muted"))
        copy.append(label(spec.description, "muted"))
        if state.installed:
            copy.append(label(state.url, "muted"))
        top.append(copy)
        top.append(status_pill("Installed" if state.installed else "Not installed", True if state.installed else False))
        box.append(top)

        if state.installed and not state.document_root_ready:
            box.append(label(f"Package installed, but expected web entry point is missing under: {spec.document_root}", "error-text", wrap=True))
        if state.installed and not state.runtime_ready:
            box.append(label(state.runtime_note, "error-text", wrap=True))

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        if not state.installed:
            install = Gtk.Button(label="Install")
            install.set_sensitive(
                state.installable
                and bool(state.php_version)
                and nginx_installed
                and self.context.distro.is_debian_family
            )
            install.add_css_class("suggested-action")
            if state.php_version:
                install.connect(
                    "clicked",
                    lambda _b, s=spec, v=state.php_version, btn=install: confirm(
                        self.window,
                        f"Install {s.title}?",
                        f"NativeDev will install the official Debian/Ubuntu package without recommended web servers, serve it at {s.key}.localhost over HTTP, and use PHP {v} FPM. Package updates remain managed by APT.",
                        lambda: self.action(
                            btn,
                            lambda: self.context.controller.install_developer_tool(s, v),
                            success_message=f"{s.title} installed",
                            after=self.refresh,
                        ),
                    ),
                )
            if not state.installable:
                box.append(label("Unavailable in configured repositories.", "muted", wrap=True))
            elif not nginx_installed:
                box.append(label("Install Nginx first.", "muted", wrap=True))
            elif not state.php_version:
                box.append(label("Install a PHP-FPM version first.", "muted", wrap=True))
            actions.append(install)
        else:
            if not state.runtime_ready:
                repair = Gtk.Button(label="Repair")
                repair.add_css_class("suggested-action")
                repair.connect(
                    "clicked",
                    lambda _b, s=spec, btn=repair: self.action(
                        btn,
                        lambda: self.context.controller.repair_developer_tool(s),
                        success_message=f"{s.title} integration repaired",
                        after=self.refresh,
                    ),
                )
                actions.append(repair)

            open_button = Gtk.Button(label="Open")
            open_button.set_sensitive(state.document_root_ready)

            def open_tool(_button, uri=state.url):
                try:
                    Gio.AppInfo.launch_default_for_uri(uri, None)
                except Exception as exc:
                    self.window.set_activity(False, str(exc), error=True)

            open_button.connect("clicked", open_tool)
            actions.append(open_button)

            php_values = list(state.php_versions)
            php_dropdown = Gtk.DropDown.new_from_strings([f"PHP {version}" for version in php_values])
            php_dropdown.set_sensitive(bool(php_values))
            try:
                php_dropdown.set_selected(php_values.index(state.php_version))
            except ValueError:
                if php_values:
                    php_dropdown.set_selected(0)
            actions.append(php_dropdown)

            uninstall = Gtk.Button(label="Uninstall")
            uninstall.add_css_class("destructive-action")
            uninstall.connect(
                "clicked",
                lambda _b, s=spec, btn=uninstall: confirm(
                    self.window,
                    f"Uninstall {s.title}?",
                    (
                        "NativeDev will remove the Adminer distro package and its NativeDev Nginx integration. If Adminer SQLite is installed, its NativeDev wrapper is also removed. SQLite database files are preserved, and NativeDev does not run autoremove."
                        if s.key == "adminer"
                        else "NativeDev will remove the distro package and its NativeDev Nginx integration. No database data or accounts are removed, and NativeDev does not run autoremove."
                    ),
                    lambda: self.action(
                        btn,
                        lambda: self.context.controller.uninstall_developer_tool(s),
                        success_message=f"{s.title} uninstalled",
                        after=self.refresh,
                    ),
                ),
            )
            actions.append(uninstall)

            def php_changed(dropdown, _param, s=spec, values=php_values, current=state.php_version):
                index = dropdown.get_selected()
                if index < 0 or index >= len(values):
                    return
                version = values[index]
                if version == current:
                    return
                self.action(
                    dropdown,
                    lambda: self.context.controller.set_developer_tool_php(s, version),
                    success_message=f"{s.title} now uses PHP {version}",
                    after=self.refresh,
                )

            php_dropdown.connect("notify::selected", php_changed)

        if actions.get_first_child():
            box.append(actions)
        return box

    def _adminer_sqlite_card(self, state, nginx_installed: bool):
        box = card()
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        copy.set_hexpand(True)
        copy.append(label("Adminer SQLite", "section-title"))
        copy.append(label("SQLite administration through Adminer", "muted"))
        if state.installed:
            copy.append(label(state.url, "muted"))
            copy.append(label(f"Password: {state.password}", "muted"))
        top.append(copy)
        top.append(status_pill("Installed" if state.installed else "Not installed", True if state.installed else False))
        box.append(top)

        if state.installed and not state.runtime_ready:
            box.append(label(state.runtime_note or "Adminer SQLite integration needs repair.", "error-text", wrap=True))

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        if not state.installed:
            install = Gtk.Button(label="Install")
            install.set_sensitive(state.installable and nginx_installed)
            install.add_css_class("suggested-action")
            if state.installable and nginx_installed:
                install.connect(
                    "clicked",
                    lambda _b, btn=install: confirm(
                        self.window,
                        "Install Adminer SQLite?",
                        "NativeDev will create a version-compatible Adminer SQLite wrapper for the installed Debian/Ubuntu Adminer package and serve it at adminer-sqlite.localhost over HTTP. The fixed local login password is nativedev. SQLite PHP extensions are not installed or enabled by this action.",
                        lambda: self.action(
                            btn,
                            self.context.controller.install_adminer_sqlite,
                            success_message="Adminer SQLite installed",
                            after=self.refresh,
                        ),
                    ),
                )
            if not state.adminer_installed:
                box.append(label("Requires Adminer. Install Adminer first.", "muted", wrap=True))
            elif not nginx_installed:
                box.append(label("Install Nginx first.", "muted", wrap=True))
            elif not state.php_version:
                box.append(label("Adminer does not currently have an available PHP-FPM runtime.", "muted", wrap=True))
            actions.append(install)
        else:
            if not state.runtime_ready:
                repair = Gtk.Button(label="Repair")
                repair.add_css_class("suggested-action")
                repair.connect(
                    "clicked",
                    lambda _b, btn=repair: self.action(
                        btn,
                        self.context.controller.repair_adminer_sqlite,
                        success_message="Adminer SQLite integration repaired",
                        after=self.refresh,
                    ),
                )
                actions.append(repair)

            open_button = Gtk.Button(label="Open")
            open_button.set_sensitive(state.runtime_ready)

            def open_sqlite(_button, uri=state.url):
                try:
                    Gio.AppInfo.launch_default_for_uri(uri, None)
                except Exception as exc:
                    self.window.set_activity(False, str(exc), error=True)

            open_button.connect("clicked", open_sqlite)
            actions.append(open_button)

            uninstall = Gtk.Button(label="Uninstall")
            uninstall.add_css_class("destructive-action")
            uninstall.connect(
                "clicked",
                lambda _b, btn=uninstall: confirm(
                    self.window,
                    "Uninstall Adminer SQLite?",
                    "NativeDev will remove only its Adminer SQLite wrapper and localhost Nginx integration. Adminer and SQLite database files are preserved.",
                    lambda: self.action(
                        btn,
                        self.context.controller.uninstall_adminer_sqlite,
                        success_message="Adminer SQLite uninstalled",
                        after=self.refresh,
                    ),
                ),
            )
            actions.append(uninstall)

        if actions.get_first_child():
            box.append(actions)
        return box

    def _use_default_database_user(self, button: Gtk.Button, spec: ComponentSpec, username: str) -> None:
        if spec.key in {"mariadb", "mysql"}:
            message = (
                f'NativeDev will first try the local MariaDB/MySQL root account without a password. '
                f'If that login is unavailable, NativeDev will ask for the MariaDB/MySQL root password. '
                f'It will then create or reset the database user "{username}" to password "nativedev" '
                'and reconcile its development privileges. The root password is never saved.'
            )
        else:
            message = (
                f'NativeDev will create or reset the current database user "{username}" to password '
                '"nativedev" and reconcile its non-superuser development privileges.'
            )
        confirm(
            self.window,
            f"Use NativeDev default {spec.title} user?",
            message,
            lambda: self._attempt_default_database_user(button, spec),
        )

    def _attempt_default_database_user(
        self,
        button: Gtk.Button,
        spec: ComponentSpec,
        admin_password: str | None = None,
    ) -> None:
        self.busy(button, True)
        self.window.set_activity(True, "Working…")

        def success(_value=None):
            self.busy(button, False)
            self.window.set_activity(False, f"{spec.title} now uses the NativeDev default database password")
            self.refresh()
            return False

        def error(exc):
            self.busy(button, False)
            if isinstance(exc, DatabaseAdminPasswordRequired) and spec.key in {"mariadb", "mysql"}:
                self.window.set_activity(False, "MariaDB/MySQL root password required")
                prompt_database_admin_password(
                    self.window,
                    f"Authenticate {spec.title} root",
                    lambda value: self._attempt_default_database_user(button, spec, value),
                )
                return False
            self.window.set_activity(False, str(exc), error=True)
            return False

        self.worker.submit_mutation(
            lambda: self.context.controller.run_mutation(
                lambda: self.context.controller.create_database_access(
                    spec.key,
                    admin_password=admin_password,
                )
            ),
            success,
            error,
        )

    def _append_database_access(self, box: Gtk.Box, spec: ComponentSpec, database) -> None:
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        section.set_margin_top(4)
        section.append(label("Local database access", "row-title"))

        if isinstance(database, Exception):
            section.append(label(str(database), "error-text", wrap=True))
            box.append(section)
            return

        if database.managed:
            grid = Gtk.Grid(column_spacing=10, row_spacing=5)
            grid.attach(label("Server", "muted"), 0, 0, 1, 1)
            grid.attach(label(f"{database.host}:{database.port}"), 1, 0, 1, 1)
            row_index = 1
            if database.database:
                grid.attach(label("Database", "muted"), 0, row_index, 1, 1)
                grid.attach(label(database.database), 1, row_index, 1, 1)
                row_index += 1
            grid.attach(label("Username", "muted"), 0, row_index, 1, 1)
            grid.attach(label(database.username), 1, row_index, 1, 1)

            username_copy = Gtk.Button(label="Copy")
            username_copy.connect("clicked", lambda *_: self._copy(database.username, "Database username copied"))
            grid.attach(username_copy, 2, row_index, 1, 1)

            row_index += 1
            grid.attach(label("Password", "muted"), 0, row_index, 1, 1)
            password_label = label("•" * max(8, min(len(database.password), 20)))
            password_label.set_hexpand(True)
            grid.attach(password_label, 1, row_index, 1, 1)
            reveal = Gtk.Button(label="Reveal")
            revealed = {"value": False}

            def toggle_password(*_):
                revealed["value"] = not revealed["value"]
                password_label.set_text(database.password if revealed["value"] else "•" * max(8, min(len(database.password), 20)))
                reveal.set_label("Hide" if revealed["value"] else "Reveal")

            reveal.connect("clicked", toggle_password)
            grid.attach(reveal, 2, row_index, 1, 1)
            password_copy = Gtk.Button(label="Copy")
            password_copy.connect("clicked", lambda *_: self._copy(database.password, "Database password copied"))
            grid.attach(password_copy, 3, row_index, 1, 1)
            section.append(grid)

            account_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            change = Gtk.Button(label="Change password")
            change.connect(
                "clicked",
                lambda *_: prompt_database_password(
                    self.window,
                    f"Change {spec.title} database password",
                    lambda value: self.action(
                        change,
                        lambda: self.context.controller.change_database_password(spec.key, value),
                        success_message=f"{spec.title} database password changed",
                        after=self.refresh,
                    ),
                ),
            )
            account_actions.append(change)

            reset = Gtk.Button(label="Reset to default")
            reset.set_sensitive(database.password != DEFAULT_DATABASE_PASSWORD)
            reset.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    f"Reset {spec.title} database password?",
                    'The NativeDev local account password will be changed back to "nativedev". Applications using the current password will need updating.',
                    lambda: self.action(
                        reset,
                        lambda: self.context.controller.reset_database_password(spec.key),
                        success_message=f"{spec.title} password reset to default",
                        after=self.refresh,
                    ),
                ),
            )
            account_actions.append(reset)
            section.append(account_actions)

        elif database.conflict:
            section.append(label(
                f'An existing local database account for "{database.username}" was detected. NativeDev did not change its password or privileges.',
                "muted",
                wrap=True,
            ))
            account_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            use_existing = Gtk.Button(label="Use existing user")
            use_existing.add_css_class("suggested-action")
            use_existing.connect(
                "clicked",
                lambda *_: prompt_existing_database_password(
                    self.window,
                    f"Use existing {spec.title} user",
                    database.username,
                    lambda value: self.action(
                        use_existing,
                        lambda: self.context.controller.use_existing_database_access(spec.key, value),
                        success_message=f"{spec.title} existing database user connected",
                        after=self.refresh,
                    ),
                ),
            )
            account_actions.append(use_existing)
            use_default = Gtk.Button(label="Use NativeDev default user")
            use_default.connect(
                "clicked",
                lambda *_: self._use_default_database_user(use_default, spec, database.username),
            )
            account_actions.append(use_default)
            section.append(account_actions)
        else:
            section.append(label(
                f'No NativeDev credential is saved for the current database user "{database.username}". Use the existing-user flow when you know its current password, or use the NativeDev default-user flow to create/reset it to password "nativedev".',
                "muted",
                wrap=True,
            ))
            account_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            use_existing = Gtk.Button(label="Use existing user")
            use_existing.add_css_class("suggested-action")
            use_existing.connect(
                "clicked",
                lambda *_: prompt_existing_database_password(
                    self.window,
                    f"Use existing {spec.title} user",
                    database.username,
                    lambda value: self.action(
                        use_existing,
                        lambda: self.context.controller.use_existing_database_access(spec.key, value),
                        success_message=f"{spec.title} existing database user connected",
                        after=self.refresh,
                    ),
                ),
            )
            account_actions.append(use_existing)
            provision = Gtk.Button(label="Use NativeDev default user")
            provision.connect(
                "clicked",
                lambda *_: self._use_default_database_user(provision, spec, database.username),
            )
            account_actions.append(provision)
            section.append(account_actions)

        box.append(section)

    def _copy(self, value: str, message: str) -> None:
        display = Gdk.Display.get_default()
        if not display:
            self.window.set_activity(False, "Clipboard is not available", error=True)
            return
        display.get_clipboard().set(value)
        self.window.set_activity(False, message)

    def _clear(self):
        while child := self.list_box.get_first_child():
            self.list_box.remove(child)


class ProjectsPage(Page):
    PHP_DEFAULT = "default"

    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(
            page_header(
                "Projects",
                "Per-project PHP-FPM version for *.test sites.",
                self.refresh,
            )
        )
        self.summary_card = card()
        self.projects_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.body.append(self.summary_card)
        self.body.append(self.projects_box)
        self.refresh()

    def refresh(self):
        self._replace(self.summary_card, [label("Loading projects…", "muted")])
        self._clear_projects()

        def collect():
            # Refresh is intentionally read-only. ACL/package changes belong to
            # the explicit Nginx site configuration action, never page loading.
            projects = self.context.localdev.projects()
            default_php = self.context.localdev.default_php_version()
            fpm_versions = self.context.php.installed_fpm_versions()
            rows = []
            for project in projects:
                rows.append(
                    {
                        "path": project,
                        "root": self.context.localdev.document_root(project),
                        "prefs": self.context.localdev.project_preferences(project),
                        "readable_error": "",
                    }
                )
            return {
                "projects": rows,
                "default_php": default_php,
                "fpm_versions": fpm_versions,
            }

        def done(data):
            summary = [label("Parked projects", "section-title")]
            summary.append(label(str(self.context.localdev.park_dir), "muted", wrap=True))
            summary.append(
                status_pill(
                    f"Default PHP-FPM: {data['default_php']}" if data["default_php"] else "No PHP-FPM installed",
                    bool(data["default_php"]),
                )
            )
            self._replace(self.summary_card, summary)

            self._clear_projects()
            if not data["projects"]:
                empty = card()
                empty.append(label("No project directories found.", "muted"))
                self.projects_box.append(empty)
                return False

            for item in data["projects"]:
                self.projects_box.append(
                    self._project_card(
                        item["path"],
                        item["root"],
                        item["prefs"],
                        data["default_php"],
                        data["fpm_versions"],
                        item["readable_error"],
                    )
                )
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    def _project_card(
        self,
        project: Path,
        docroot: Path,
        prefs: dict[str, str],
        default_php: str,
        fpm_versions: list[str],
        readable_error: str,
    ) -> Gtk.Widget:
        box = card()
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=18)
        copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        copy.set_hexpand(True)
        copy.append(label(f"{project.name}.{self.context.config.domain}", "section-title"))
        copy.append(label(str(project), "muted", wrap=True))
        if docroot != project:
            copy.append(label(f"Document root: {docroot}", "muted", wrap=True))
        top.append(copy)

        controls = Gtk.Grid(column_spacing=10, row_spacing=8)
        controls.set_valign(Gtk.Align.CENTER)

        php_labels = [f"Default ({default_php})" if default_php else "Default"] + [
            f"PHP {version}" for version in fpm_versions
        ]
        php_values = [self.PHP_DEFAULT, *fpm_versions]
        php_dropdown = Gtk.DropDown.new_from_strings(php_labels)
        try:
            php_index = php_values.index(prefs.get("php", self.PHP_DEFAULT))
        except ValueError:
            php_index = 0
        php_dropdown.set_selected(php_index)
        php_dropdown.set_sensitive(bool(default_php or fpm_versions))

        controls.attach(label("PHP"), 0, 0, 1, 1)
        controls.attach(php_dropdown, 1, 0, 1, 1)
        top.append(controls)
        box.append(top)

        if readable_error:
            box.append(label(f"Nginx read access: {readable_error}", "error-text", wrap=True))
        else:
            box.append(
                label(
                    f"PHP runs as {self.context.php.developer_user} (same as your terminal). "
                    "Nginx only has read access to the document root shown above.",
                    "muted",
                    wrap=True,
                )
            )

        def php_changed(dropdown, _param):
            selected = dropdown.get_selected()
            if selected < 0 or selected >= len(php_values):
                return
            value = php_values[selected]
            if value == prefs.get("php", self.PHP_DEFAULT):
                return
            self.action(
                dropdown,
                lambda: self.context.controller.set_project_php(project, value),
                success_message=f"{project.name} now uses {'Default PHP' if value == 'default' else 'PHP ' + value}",
                after=self.refresh,
            )

        php_dropdown.connect("notify::selected", php_changed)
        return box

    def _clear_projects(self):
        while child := self.projects_box.get_first_child():
            self.projects_box.remove(child)

    @staticmethod
    def _replace(container: Gtk.Box, children: list[Gtk.Widget]):
        while child := container.get_first_child():
            container.remove(child)
        for child in children:
            container.append(child)


class LocalDevPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("Local development", "Park projects, configure *.test, Nginx and trusted local HTTPS.", self.refresh))
        self.settings_card = card()
        self.dns_card = card()
        self.nginx_card = card()
        self.https_card = card()
        self.body.append(self.settings_card)
        self.body.append(self.dns_card)
        self.body.append(self.nginx_card)
        self.body.append(self.https_card)
        self.refresh()

    def refresh(self):
        self._build_settings()
        self._replace(self.dns_card, [label("Checking DNS…", "muted")])
        self._replace(self.nginx_card, [label("Checking sites…", "muted")])
        self._replace(self.https_card, [label("Checking HTTPS tools…", "muted")])

        def collect():
            return {
                "dns": self.context.localdev.dns_ready(),
                "strategy": self.context.localdev.dns_strategy(),
                "projects": self.context.localdev.projects(),
                "nginx": self.context.localdev.nginx_ready(),
                "mkcert": self.context.localdev.mkcert_installed(),
                "https": self.context.config.https_enabled,
            }

        def done(data):
            dns = [label(f"*.{self.context.config.domain} DNS", "section-title")]
            dns.append(status_pill("Ready" if data["dns"] else f"Not configured ({data['strategy']})", data["dns"]))
            dns_btn = Gtk.Button(label="Configure automatically")
            dns_btn.set_sensitive(data["strategy"] == "networkmanager")
            dns_btn.add_css_class("suggested-action")
            dns_btn.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Configure wildcard DNS?",
                    "NativeDev will add its own NetworkManager dnsmasq snippets and reload only NetworkManager DNS configuration. It will not restart NetworkManager or overwrite /etc/resolv.conf.",
                    lambda: self.action(dns_btn, self.context.localdev.configure_dns, success_message="Wildcard DNS configured", after=self.refresh),
                ),
            )
            dns.append(dns_btn)
            self._replace(self.dns_card, dns)

            sites = [label("Wildcard Nginx routing", "section-title")]
            sites.append(status_pill("Automatic routing ready" if data["nginx"] else "Not configured / legacy config", data["nginx"]))
            sites.append(
                label(
                    f"After one-time setup, a new folder named with lowercase letters, numbers or hyphens inside {self.context.localdev.park_dir} "
                    f"is immediately available as folder.{self.context.config.domain} — NativeDev does not need to be open. "
                    "A public/ directory is selected automatically when present. Default PHP is used unless a project is pinned on the Projects page.",
                    "muted",
                    wrap=True,
                )
            )
            if data["projects"]:
                sites.append(label(f"{len(data['projects'])} projects currently detected.", "muted", wrap=True))
            site_btn = Gtk.Button(label="Repair / rebuild wildcard routing" if data["nginx"] else "Configure wildcard routing")
            site_btn.add_css_class("suggested-action")
            site_btn.connect(
                "clicked",
                lambda *_: confirm(
                    self.window,
                    "Configure NativeDev wildcard Nginx routing?",
                    "NativeDev will install one persistent *.test router, prepare an inheritable read-only Nginx ACL on the park directory, validate with nginx -t, and reload Nginx. New projects will not require regeneration.",
                    lambda: self.action(site_btn, self.context.localdev.configure_nginx_sites, success_message="Wildcard Nginx routing ready", after=self.refresh),
                ),
            )
            sites.append(site_btn)
            self._replace(self.nginx_card, sites)

            https = [label("Local HTTPS", "section-title")]
            https.append(status_pill("mkcert installed" if data["mkcert"] else "mkcert missing", data["mkcert"]))
            if data["mkcert"]:
                trust = Gtk.Button(label="Trust local CA")
                trust.connect("clicked", lambda *_: self.action(trust, self.context.localdev.trust_mkcert_ca, success_message="Local CA trust configured"))
                enable = Gtk.Button(label=(f"Generate *.{self.context.config.domain} certificate"))
                enable.add_css_class("suggested-action")
                enable.connect(
                    "clicked",
                    lambda *_: confirm(
                        self.window,
                        "Enable HTTPS for local sites?",
                        "A wildcard certificate is generated with mkcert and copied to NativeDev's Nginx certificate directory.",
                        lambda: self.action(enable, self.context.localdev.enable_https, success_message="HTTPS enabled", after=self.refresh),
                    ),
                )
                actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                actions.append(trust)
                actions.append(enable)
                https.append(actions)
            else:
                https.append(label("Install mkcert from Services & tools first.", "muted"))
            self._replace(self.https_card, https)
            return False

        self.worker.submit(collect, done, lambda exc: self.window.set_activity(False, str(exc), error=True))

    def _build_settings(self):
        self._replace(self.settings_card, [])
        self.settings_card.append(label("Project settings", "section-title"))
        grid = Gtk.Grid(column_spacing=10, row_spacing=10)
        park = Gtk.Entry()
        park.set_text(self.context.config.park_dir)
        domain = Gtk.Entry()
        domain.set_text(self.context.config.domain)
        domain.set_max_length(30)
        grid.attach(label("Park directory"), 0, 0, 1, 1)
        grid.attach(park, 1, 0, 1, 1)
        grid.attach(label("Local TLD"), 0, 1, 1, 1)
        grid.attach(domain, 1, 1, 1, 1)
        self.settings_card.append(grid)
        self.settings_card.append(
            label(
                "Projects use the system Default PHP-FPM automatically. Override PHP per site from Projects. "
                "Changing the park directory or local TLD automatically reconciles existing NativeDev DNS/Nginx routing.",
                "muted",
                wrap=True,
            )
        )
        save = Gtk.Button(label="Save settings")
        save.add_css_class("suggested-action")

        def save_settings(*_):
            value = domain.get_text().strip().lower().lstrip(".")
            if not value or any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789-" for ch in value):
                self.window.set_activity(False, "Local TLD must contain only letters, numbers or hyphens", error=True)
                return
            park_value = str(Path(park.get_text()).expanduser())

            self.action(
                save,
                lambda: self.context.controller.update_localdev_settings(park_value, value),
                success_message="Settings saved and local routing reconciled",
                after=self.refresh,
            )

        save.connect("clicked", save_settings)
        self.settings_card.append(save)

    @staticmethod
    def _replace(container: Gtk.Box, children: list[Gtk.Widget]):
        while child := container.get_first_child():
            container.remove(child)
        for child in children:
            container.append(child)


class DoctorPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("Doctor", "Read-only diagnostics for the current system.", self.refresh))
        self.card = card()
        self.output = Gtk.TextView()
        self.output.set_editable(False)
        self.output.set_cursor_visible(False)
        self.output.set_monospace(True)
        self.output.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.card.append(self.output)
        self.body.append(self.card)
        self.refresh()

    def refresh(self):
        self.output.get_buffer().set_text("Running diagnostics…")

        def done(checks):
            self.output.get_buffer().set_text(self.context.doctor.format(checks))
            return False

        self.worker.submit(self.context.doctor.run, done, lambda exc: self.output.get_buffer().set_text(str(exc)))


class AboutPage(Page):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.body.append(page_header("About", "NativeDev application information and updates."))

        info = card()
        info.append(label("NativeDev", "section-title"))
        info.append(label(f"Version {__version__}"))
        info.append(label("NativeDev provides a graphical control plane for a native PHP development stack on Linux."))
        release_link = Gtk.LinkButton.new_with_label(
            "https://github.com/sayedsahin/nativedev/",
            "GitHub: https://github.com/sayedsahin/nativedev"
        )

        release_link.add_css_class("muted")

        info.append(release_link)
        self.body.append(info)

        update_card = card()

        self.update_button = Gtk.Button(label="Check for updates")
        self.update_button.add_css_class("suggested-action")
        self.update_button.connect("clicked", self._check_updates)
        update_card.append(self.update_button)
        self.body.append(update_card)

    def _check_updates(self, *_args):
        self.update_button.set_sensitive(False)
        self.window.set_activity(True, "Checking for updates…")

        def done(update):
            self.update_button.set_sensitive(True)
            if update is None:
                self.window.set_activity(False, "NativeDev is up to date.")
            else:
                self.window._show_update_dialog(update)
                self.window.set_activity(False, "Update available.")
            return False

        def failed(exc):
            self.update_button.set_sensitive(True)
            self.window.set_activity(False, str(exc), error=True)
            return False

        self.worker.submit(
            lambda: self.context.application.check_for_update(force=True),
            done,
            failed,
        )


class MainWindow(Gtk.ApplicationWindow):
    # Only top-level destinations belong in the sidebar. PHP Extensions and PHP
    # Settings are contextual subpages opened from the PHP page.
    PAGES = (
        ("dashboard", "Dashboard", DashboardPage),
        ("local", "Local development", LocalDevPage),
        ("services", "Services & tools", ServicesPage),
        ("php", "PHP", PhpPage),
        ("node", "Node.js", NodePage),
        ("projects", "Projects", ProjectsPage),
        ("doctor", "Doctor", DoctorPage),
        ("about", "About", AboutPage),
    )
    PHP_SUBPAGES = (
        ("extensions", PhpExtensionsPage),
        ("php_ini", PhpIniPage),
    )

    def __init__(self, application: Gtk.Application, context: AppContext):
        super().__init__(application=application)
        self.context = context
        self.worker = Worker()
        self._update_check_in_flight = False
        self._update_dialog_visible = False
        self._update_timer_id = GLib.timeout_add_seconds(60 * 60, self._update_timer_tick)
        self.set_title(f"NativeDev {__version__}")
        self.set_default_size(1040, 700)
        self.set_size_request(760, 520)

        header = Gtk.HeaderBar()
        title = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        title.append(label("NativeDev", "app-title"))
        title.append(label(f"Native system development manager · {__version__}", "muted"))
        header.set_title_widget(title)
        self.set_titlebar(header)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        root.append(content)

        self.sidebar = Gtk.ListBox()
        self.sidebar.add_css_class("sidebar")
        self.sidebar.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.sidebar.set_size_request(210, -1)
        content.append(self.sidebar)

        self.stack = Gtk.Stack()
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        content.append(self.stack)

        self.statusbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.statusbar.add_css_class("statusbar")
        self.statusbar.set_margin_start(14)
        self.statusbar.set_margin_end(14)
        self.statusbar.set_margin_top(7)
        self.statusbar.set_margin_bottom(7)
        self.activity_spinner = Gtk.Spinner()
        self.activity_spinner.set_visible(False)
        self.statusbar.append(self.activity_spinner)
        self.status = label("Ready")
        self.status.set_hexpand(True)
        self.status.set_wrap(True)
        self.status.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        self.status.set_max_width_chars(72)
        self.statusbar.append(self.status)
        self.status_copy = Gtk.Button(label="Copy")
        self.status_copy.set_valign(Gtk.Align.CENTER)
        self.status_copy.set_tooltip_text("Copy error message")
        self.status_copy.set_visible(False)
        self.status_copy.connect("clicked", self._copy_status_error)
        self.statusbar.append(self.status_copy)
        self._status_message = "Ready"
        root.append(self.statusbar)
        self.set_child(root)

        self.pages: dict[str, Page] = {}
        for key, title_text, klass in self.PAGES:
            row = Gtk.ListBoxRow()
            row.set_name(key)
            nav_label = label(title_text, "nav-label")
            nav_label.set_margin_top(11)
            nav_label.set_margin_bottom(11)
            nav_label.set_margin_start(14)
            nav_label.set_margin_end(14)
            row.set_child(nav_label)
            self.sidebar.append(row)
            page = klass(self)
            self.pages[key] = page
            self.stack.add_named(page, key)

        for key, klass in self.PHP_SUBPAGES:
            page = klass(self)
            self.pages[key] = page
            self.stack.add_named(page, key)

        self.sidebar.connect("row-selected", self._on_row_selected)
        self.sidebar.select_row(self.sidebar.get_row_at_index(0))
        self.connect("close-request", self._on_close)

        if not self.context.distro.is_debian_family:
            self.set_activity(False, f"{self.context.distro.pretty_name} is outside the supported Debian/Ubuntu family", error=True)

    def _on_row_selected(self, _listbox, row):
        if row:
            self.stack.set_visible_child_name(row.get_name())

    def open_php_subpage(self, key: str) -> None:
        if key not in {name for name, _klass in self.PHP_SUBPAGES}:
            raise RuntimeError(f"Unknown PHP subpage: {key}")
        page = self.pages[key]
        page.refresh()
        self.stack.set_visible_child_name(key)

    def open_php_page(self) -> None:
        # Returning from PHP Extensions/Settings is navigation only. Those
        # subpages do not mutate the PHP runtime/provider inventory shown on
        # the parent page, so avoid an unnecessary asynchronous refresh.
        self.stack.set_visible_child_name("php")

    def _update_timer_tick(self) -> bool:
        # The lightweight hourly timer only checks the local timestamp. The
        # package metadata probe itself still runs at most once per 24 hours.
        self.check_for_updates()
        return GLib.SOURCE_CONTINUE

    def check_for_updates(self) -> None:
        """Run the 24-hour package update probe without blocking GTK."""
        if self._update_check_in_flight or not self.context.application.check_due():
            return
        self._update_check_in_flight = True

        def done(update: ApplicationUpdate | None):
            self._update_check_in_flight = False
            if update is not None:
                self._show_update_dialog(update)
            return False

        def failed(_exc):
            self._update_check_in_flight = False
            return False

        # Background update checks are intentionally silent on package metadata
        # failures. They must never turn app startup into an error or
        # authorization prompt. The manager records the attempt so the 24-hour
        # policy is still respected.
        self.worker.submit(
            self.context.application.check_for_update,
            done,
            failed,
        )

    def _show_update_dialog(self, update: ApplicationUpdate) -> None:
        if self._update_dialog_visible:
            return
        self._update_dialog_visible = True
        dialog = Gtk.Dialog(title="NativeDev update available", transient_for=self, modal=True)
        dialog.set_default_size(440, -1)
        dialog.add_button("Later", Gtk.ResponseType.CANCEL)
        update_button = dialog.add_button("Update", Gtk.ResponseType.OK)
        update_button.add_css_class("suggested-action")

        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_margin_top(14)
        content.set_margin_bottom(14)
        content.set_margin_start(16)
        content.set_margin_end(16)
        content.append(_constrain_dialog_text(label(
            f"NativeDev {update.candidate_version} is available. "
            f"You are using {update.installed_version}.",
            wrap=True,
        )))
        content.append(_constrain_dialog_text(label(
            "Update uses your Linux package manager and may ask for system authorization.",
            "muted",
            wrap=True,
        )))

        def response(_dialog, response_id):
            self._update_dialog_visible = False
            dialog.destroy()
            if response_id == Gtk.ResponseType.OK:
                self._install_application_update(update)

        dialog.connect("response", response)
        dialog.present()

    def _install_application_update(self, update: ApplicationUpdate) -> None:
        self.set_activity(True, "Working…")

        def success(_value=None):
            self.set_activity(False, f"NativeDev {update.candidate_version} installed. Restart to use the new version.")
            self._show_restart_dialog(update.candidate_version)
            return False

        def error(exc):
            self.set_activity(False, str(exc), error=True)
            return False

        self.worker.submit_mutation(
            self.context.controller.update_application, success, error
        )

    def _show_restart_dialog(self, installed_version: str) -> None:
        dialog = Gtk.Dialog(title="Update installed", transient_for=self, modal=True)
        dialog.set_default_size(420, -1)
        dialog.add_button("Later", Gtk.ResponseType.CANCEL)
        restart = dialog.add_button("Restart NativeDev", Gtk.ResponseType.OK)
        restart.add_css_class("suggested-action")
        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_margin_top(14)
        content.set_margin_bottom(14)
        content.set_margin_start(16)
        content.set_margin_end(16)
        content.append(_constrain_dialog_text(label(
            f"NativeDev {installed_version} has been installed. Restart NativeDev to load the updated application and privileged helper.",
            wrap=True,
        )))

        def response(_dialog, response_id):
            dialog.destroy()
            if response_id != Gtk.ResponseType.OK:
                return
            launcher = shutil.which("nativedev")
            if not launcher:
                self.set_activity(False, "Update installed. Restart NativeDev manually.")
                return
            try:
                subprocess.Popen(
                    [launcher],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            except OSError as exc:
                self.set_activity(False, f"Update installed, but restart failed: {exc}", error=True)
                return
            application = self.get_application()
            if application:
                application.quit()

        dialog.connect("response", response)
        dialog.present()

    def _copy_status_error(self, *_args) -> None:
        if not self._status_message:
            return
        display = Gdk.Display.get_default()
        if display:
            display.get_clipboard().set(self._status_message)

    def set_activity(self, active: bool, message: str, *, error: bool = False):
        self.status.remove_css_class("error-text")
        self.status.remove_css_class("muted")
        self.status.set_selectable(False)
        self.status_copy.set_visible(False)
        if active:
            self.activity_spinner.set_visible(True)
            self.activity_spinner.start()
            self._status_message = ""
            self.status.set_text("")
            self.status.add_css_class("muted")
            return

        self.activity_spinner.stop()
        self.activity_spinner.set_visible(False)
        self._status_message = message
        self.status.set_text(message)
        if error:
            self.status.add_css_class("error-text")
            self.status.set_selectable(True)
            self.status_copy.set_visible(bool(message))

    def _on_close(self, *_):
        if self._update_timer_id:
            GLib.source_remove(self._update_timer_id)
            self._update_timer_id = 0
        self.worker.shutdown()
        self.context.runner.close()
        return False


class NativeDevApplication(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="io.github.nativedev.Manager")
        self.context = AppContext.create()
        self.window: MainWindow | None = None

    def do_startup(self):
        Gtk.Application.do_startup(self)
        self._load_css()

    def do_activate(self):
        if not self.window:
            self.window = MainWindow(self, self.context)
        self.window.present()
        self.window.check_for_updates()

    @staticmethod
    def _load_css():
        css_path = Path(__file__).with_name("style.css")
        provider = Gtk.CssProvider()
        provider.load_from_path(str(css_path))
        display = Gdk.Display.get_default()
        if display:
            Gtk.StyleContext.add_provider_for_display(
                display,
                provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
            )
