from __future__ import annotations

import re
import shutil
from dataclasses import dataclass
from pathlib import Path

from .system import AptManager, CommandRunner, SystemdManager


@dataclass(frozen=True, slots=True)
class ComponentSpec:
    key: str
    title: str
    packages: tuple[str, ...]
    service: str | None = None
    binary: str | None = None
    note: str = ""


COMPONENTS: tuple[ComponentSpec, ...] = (
    ComponentSpec("nginx", "Nginx", ("nginx",), "nginx", "nginx"),
    ComponentSpec(
        "mariadb",
        "MariaDB / MySQL",
        ("mariadb-server", "mariadb-client"),
        "mariadb",
        "mariadb",
        "MySQL-compatible server; NativeDev installs MariaDB from the system repositories.",
    ),
    ComponentSpec("postgresql", "PostgreSQL", ("postgresql", "postgresql-client"), "postgresql", "psql"),
    ComponentSpec(
        "redis",
        "Redis",
        ("redis-server", "redis-tools"),
        "redis-server",
        "redis-cli",
        "Redis Server and redis-cli are installed and removed together.",
    ),
    ComponentSpec("memcached", "Memcached", ("memcached",), "memcached", "memcached"),
    ComponentSpec(
        "rabbitmq",
        "RabbitMQ",
        ("rabbitmq-server",),
        "rabbitmq-server",
        "rabbitmqctl",
        "Native RabbitMQ message broker from the system repositories.",
    ),
    ComponentSpec("composer", "Composer", ("composer",), None, "composer", "CLI tool; no system service."),
    ComponentSpec("mkcert", "mkcert", ("mkcert",), None, "mkcert", "Local certificate tool; no system service."),
    ComponentSpec(
        "mailpit",
        "Mailpit",
        (),
        "mailpit",
        "mailpit",
        "Local email testing: Web UI localhost:8025, SMTP localhost:1025.",
    ),
)


# Debian's PostgreSQL meta-packages and MariaDB top-level packages can be
# removed while their actual version/core runtimes remain installed. Include
# those runtime packages so Uninstall removes the executable service/client,
# but deliberately leave common/shared packages and database data alone.
POSTGRESQL_RUNTIME_RE = re.compile(r"^postgresql(?:-client)?-\d+(?:\.\d+)*$")
MARIADB_RUNTIME_RE = re.compile(r"^mariadb-(?:server|client)-core(?:-\d+(?:\.\d+)*)?$")


MAILPIT_BINARY_PATH = Path("/usr/local/bin/mailpit")
MAILPIT_SERVICE_PATH = Path("/etc/systemd/system/mailpit.service")
MAILPIT_MANAGED_MARKER = "# Managed by NativeDev"


@dataclass(slots=True)
class ComponentState:
    spec: ComponentSpec
    installed: bool
    packages_installed: bool
    installable: bool
    running: bool
    enabled: bool
    enabled_state: str
    service_available: bool
    uninstallable: bool
    uninstall_note: str
    binary_path: str | None
    version: str | None


class ServiceManager:
    def __init__(self, runner: CommandRunner, apt: AptManager, systemd: SystemdManager):
        self.runner = runner
        self.apt = apt
        self.systemd = systemd

    def _installed_package_names(self) -> set[str]:
        result = self.runner.run(
            ["dpkg-query", "-W", "-f=${db:Status-Abbrev}\t${binary:Package}\n"],
            timeout=45,
        )
        if not result.ok:
            return set()

        packages: set[str] = set()
        for raw in result.stdout.splitlines():
            status, separator, package = raw.partition("\t")
            if not separator or not status.startswith("ii "):
                continue
            packages.add(package.strip().split(":", 1)[0])
        return packages

    def installed_component_packages(self, spec: ComponentSpec) -> list[str]:
        """Return installed packages that make a component present in the UI."""
        installed = self._installed_package_names()
        wanted = {package for package in spec.packages if package in installed}

        if spec.key == "postgresql":
            wanted.update(package for package in installed if POSTGRESQL_RUNTIME_RE.fullmatch(package))
        elif spec.key == "mariadb":
            wanted.update(package for package in installed if MARIADB_RUNTIME_RE.fullmatch(package))

        return sorted(wanted)

    def state(self, spec: ComponentSpec) -> ComponentState:
        installed_packages = self.installed_component_packages(spec)
        packages_installed = bool(installed_packages)
        binary_path = shutil.which(spec.binary) if spec.binary else None
        uninstallable = packages_installed
        uninstall_note = ""

        if spec.key == "mailpit":
            managed = self._mailpit_managed()
            service_file_present = MAILPIT_SERVICE_PATH.is_file()
            fixed_binary_present = MAILPIT_BINARY_PATH.is_file()
            if fixed_binary_present:
                binary_path = str(MAILPIT_BINARY_PATH)
            # Mailpit is intentionally not modelled as an APT package: upstream
            # ships a static Linux binary. Treat either its binary or service
            # unit as presence, but only allow NativeDev uninstall when our
            # marker proves the unit belongs to NativeDev.
            packages_installed = bool(binary_path or service_file_present)
            uninstallable = managed
            if packages_installed and not managed:
                uninstall_note = "Existing Mailpit installation detected; NativeDev will not remove files it does not manage."

        # A partially removed component (for example postgresql meta-package gone
        # but postgresql-client-17 still installed) must remain visible as
        # installed/uninstallable so NativeDev can finish the cleanup.
        installed = packages_installed
        if not spec.service and binary_path:
            installed = True

        installable = True if spec.key == "mailpit" else any(self.apt.candidate(pkg) for pkg in spec.packages)

        enabled_state = "n/a"
        service_available = False
        running = False
        enabled = False
        if spec.service and packages_installed:
            enabled_state = self.systemd.enabled_state(spec.service)
            service_available = enabled_state not in {"n/a", "not-found"} and not enabled_state.startswith("Failed ")
            if service_available:
                running = self.systemd.is_active(spec.service)
                enabled = enabled_state in {"enabled", "enabled-runtime", "linked", "linked-runtime"}

        version = self._component_version(spec, binary_path) if installed else None

        return ComponentState(
            spec=spec,
            installed=installed,
            packages_installed=packages_installed,
            installable=installable,
            running=running,
            enabled=enabled,
            enabled_state=enabled_state,
            service_available=service_available,
            uninstallable=uninstallable,
            uninstall_note=uninstall_note,
            binary_path=binary_path,
            version=version,
        )

    def install(self, spec: ComponentSpec) -> None:
        if spec.key == "mailpit":
            self.runner.privileged_operation("mailpit.install", check=True, timeout=600)
            return

        installable = [pkg for pkg in spec.packages if self.apt.candidate(pkg)]
        if not installable:
            raise RuntimeError(f"No installable APT package found for {spec.title}")
        self.apt.install(installable)
        if spec.service:
            self.systemd.enable_now(spec.service)

    def uninstall(self, spec: ComponentSpec) -> None:
        """Remove managed runtimes without broad purge/autoremove cleanup.

        Database credential metadata is cleared by the controller after this
        succeeds. Debian common/shared packages and on-disk database clusters
        are intentionally preserved, matching NativeDev's original stable
        uninstall behavior. Mailpit's persistent message store is also kept.
        """
        if spec.key == "mailpit":
            if not self._mailpit_managed():
                raise RuntimeError("Mailpit is not managed by NativeDev")
            self.runner.privileged_operation("mailpit.uninstall", check=True, timeout=300)
            return

        installed = self.installed_component_packages(spec)
        if not installed:
            raise RuntimeError(f"{spec.title} is not installed through APT")
        if spec.service:
            try:
                self.systemd.disable_now(spec.service)
            except RuntimeError:
                pass
        # Database removal is deliberately the ordinary APT remove path. Do not
        # impose an arbitrary wall-clock timeout: maintainer scripts may
        # legitimately take time. The privileged helper makes APT non-interactive
        # and fails immediately when dpkg is already busy, so the GUI never sits
        # waiting on a lock or hidden prompt.
        if spec.key in {"mariadb", "postgresql"}:
            self.apt.remove(installed, timeout=None)
        else:
            self.apt.remove(installed)

    def delete_database_data(self, spec: ComponentSpec) -> None:
        """Delete the complete local database state for an explicit reset uninstall.

        This is intentionally separate from normal package removal. The root
        helper owns the fixed distro paths; no filesystem path crosses the
        privilege boundary. Removing the data/cluster state also removes all
        database users, roles and passwords stored inside it.
        """
        if spec.key not in {"mariadb", "postgresql"}:
            raise RuntimeError(f"{spec.title} is not a database component")
        self.runner.privileged_operation(
            "database.delete_all_data",
            key=spec.key,
            check=True,
            timeout=None,
        )

    @staticmethod
    def _mailpit_managed() -> bool:
        try:
            return MAILPIT_MANAGED_MARKER in MAILPIT_SERVICE_PATH.read_text(encoding="utf-8")
        except OSError:
            return False

    def _component_version(self, spec: ComponentSpec, binary_path: str | None) -> str | None:
        if spec.key != "mariadb" or not binary_path:
            return None
        result = self.runner.run([binary_path, "--version"], timeout=15)
        if not result.ok:
            return None
        match = re.search(r"\bDistrib\s+([^,\s]+)", result.output)
        if match:
            return match.group(1)
        match = re.search(r"\b(\d+\.\d+(?:\.\d+)?(?:-MariaDB)?)\b", result.output)
        return match.group(1) if match else None

    def start(self, spec: ComponentSpec) -> None:
        self._require_service(spec)
        self.systemd.start(spec.service)

    def stop(self, spec: ComponentSpec) -> None:
        self._require_service(spec)
        self.systemd.stop(spec.service)

    def restart(self, spec: ComponentSpec) -> None:
        self._require_service(spec)
        self.systemd.restart(spec.service)

    def enable(self, spec: ComponentSpec) -> None:
        self._require_service(spec)
        self.systemd.enable(spec.service)

    def disable(self, spec: ComponentSpec) -> None:
        self._require_service(spec)
        self.systemd.disable(spec.service)

    @staticmethod
    def _require_service(spec: ComponentSpec) -> None:
        if not spec.service:
            raise RuntimeError(f"{spec.title} has no system service")
